--identify the good ones template
select distinct Y.dcsid,
CASE
	WHEN Y.cBatches = Y.eBatches
	and Y.Docs = Y.xTimes
	Then 'Matching'
	Else null
	End Status
	into xdcsid_20230609_mtv_matchingxx02
FROM
(select distinct X.dcsid,
X.cBatches,
count(distinct d.PBatch) eBatches,
count(distinct d.imageid) Docs,
count(distinct CONVERT(varchar, d.ftpstime,1) + imageid) xTimes
FROM
(select distinct x.dcsid dcsid, count(distinct p.pbatch) cBatches
from xdcsid_20230609_mtv x
left join PbatchDCSMapping p
on x.dcsid = p.dcsid
where p.Pbatch not like '%test%'
group by x.dcsid) X
left join document d
on X.dcsid = d.dcsID
where d.ftpstime is not null
--and not exists (select * from xvre_20220225_sc where d.dcsid = dcsid)
group by X.dcsid,
X.cBatches) Y

select * from xDCSIDS20220902mtv_matchingxx02

--trying to finalize for mass update
select distinct T.ImageID imageId, T.dcsID dcsid, 
count(distinct d.imageid) totalPDFs
--into xDCSIDS20220425xxx02
FROM
(select distinct d.ImageID, PBatch, T.dcsID, d.newimageid
FROM
(select distinct dcsid, max(ftpstime) UploadDateTime from document where dcsid in (
select distinct dcsID from xdcsid_20230609_mtv_matchingxx02
where status = 'matching')
and filesize <> 0
and len(newimageid) < 2
group by dcsid) T
left join document d
on T.UploadDateTime = d.ftpstime
and T.dcsID = d.dcsID) T
--order by pbatch desc
left join document d
on T.dcsID = d.dcsID
group by T.ImageID, T.dcsID

--trying to finalize for mass update
select distinct T.ImageID imageId, T.dcsID dcsid, 
count(distinct d.imageid) totalPDFs
--into xVRE_20220225_sc
FROM
(select distinct d.ImageID, PBatch, T.dcsID, d.newimageid
FROM
(select distinct dcsid, max(ftpstime) UploadDateTime from document where dcsid in (
select distinct dcsID from xMissingDCS20220225_matchx
where status = 'matching')
and filesize <> 0
and len(newimageid) < 2
group by dcsid) T
left join document d
on T.UploadDateTime = d.ftpstime
and T.dcsID = d.dcsID) T
--order by pbatch desc
left join document d
on T.dcsID = d.dcsID
group by T.ImageID, T.dcsID


select distinct dcsid
into xdcsid_20230609_mtv
from pbatchdcsmapping
where dcsid in (
'KZRHGJG1RR9VEO',
'KZRHI3X14Y5M43',
'LEHD11GO3PD67T',
'LERMS7FWAQOAT5',
'LF31A7YLSJQ4ZF',
'LF9U9N7VOR5LA2',
'LFB35NKG-HX83DB',
'LFB757P5WBZPUY',
'LFCFCOARH6MZL3',
'LFCFSC4QE09C0V',
'LFGYZ0U5ILN113',
'LFMPP7C9-S66E4F',
'LFMPS06Q-E5JLC0',
'LFMPVZ0R-A2ZVHB',
'LFMPZ22S-GL3J19',
'LFMQ09PK-5PY08U',
'LFMQ2JRNBVJR39',
'LFMQ4BIDZCN28N',
'LFMQ7LQQ-PMC4QU',
'LFMQ9V62-O0F9D0',
'LFMQDA3Y-OP66MH',
'LFMQEQUK1MEYQJ',
'LFMQFYZ9AFXCP4',
'LFMQJ17X-8WIWOS',
'LFMQL0AC-21MYXD',
'LFMQNFOS6Z3980',
'LFMQRYOG-W6I2XN',
'LFMQX81UEY295N',
'LFMR3G2F-5UMF7R',
'LFMR4NOD-80S4N6',
'LFMRCWWP-9RM4XR',
'LFMRG6E5-3J851N',
'LFMRHGPH-XMYGMN',
'LFMRKJGJ-IVC5LJ',
'LFMRN8DU-YABVID',
'LFMROJ9E-LDTQJQ',
'LFMRQGIX-YFN9IC',
'LFMRSE9QHN3S0O',
'LFMRWY76CCIN9A',
'LFMS1EM6-D52F9C',
'LFMS2KJ5-Z0JTEV',
'LFMS9W4G70EMET',
'LFSDBJ1J-NUT38S',
'LFWORIHII9BE1M',
'LG0UUXIZ-GQXOF4',
'LG0V27KD-U9ZOEQ',
'LG0WB254-YG0MNO',
'LG0XAAN6-FEEZB6',
'LG0XGS2U-NO481F',
'LGB8NGDYVL1CT1',
'LGCUTGZZ-G82LQZ',
'LGDKNI6LFTIFR3',
'LGDRHQ9UKO891',
'LGDRM1OR-ZDPXCW',
'LGDW7CCT-31D029',
'LGDWCMAUD8BBMQ',
'LGDYNB9N-RHM7BV',
'LGDYRCMZCA0KY3',
'LGDZ2GIS-M3DHTH',
'LGDZKI6BQTZH28',
'LGDZZOQ5SW1CWX',
'LGE1IK2W-RP7MLE',
'LGF0UOZ69QZJP7',
'LGFCTS7SNHWA6Q',
'LGFL88WK-64OX07',
'LGGHDGNJ1Z5B6N',
'LGML2E3ZDP21HF',
'LGOGA658-ADGX0W',
'LGOGGMX3B3X25D',
'LGPJBNUKX78CI3',
'LHRZD3NC-XBF8VF')

