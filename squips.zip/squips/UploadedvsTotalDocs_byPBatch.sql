select distinct PBatch BatchName, RMN, 
--DCSID, 
count(distinct imageid) Docs,
count(distinct CONVERT(varchar, ftpstime,1) + imageid) UploadDocs,
--, PBatch BatchName,
'Batch uploaded successfully on ' + CONVERT(varchar, max(ftpstime), 1) [IT Comments]
--LastUploadDateTime 
from document where pbatch in (
'02231421715901', 
'02231431211806', 
'02231442203001') 
group by pbatch, rmn
--, dcsid
order by pbatch

select * from document where pbatch = '02220951814041'
select * from customerCheckin20131118 where rmn = '349VB0311229263E'
select * from customerCheckin where rmn = '349VB0311229263E'

select * from stats where kbatch in (
'02221615101830',
'02221615101831')

select * from PbatchDCSMapping where pbatch in (
'02221615101830',
'02221615101831')

select * from document where rmn = '376VB0110223927A' and ftpstime is null

select * from manifestDCS where dcsid = 'KZMZCSVV-BGIRK2'
select * from PhysicalBatch where pbatch like '022302719038%'

--with dcsid
select distinct PBatch BatchName, RMN, dcsID, count(distinct imageid) Docs,
count(distinct CONVERT(varchar, ftpstime,1) + imageid) UploadDocs,
'Batch/DCSID uploaded successfully on ' + CONVERT(varchar, max(ftpstime), 1) [IT Comments] 
from document where dcsid in (
'02230371001909',
'02230371101927', 
'02230371308808',
'02230381201110',
'02230381202208')
group by pbatch, rmn, dcsID
order by dcsid, pbatch

--by RMN
select distinct PBatch BatchName, RMN, count(distinct imageid) Docs,
count(distinct CONVERT(varchar, ftpstime,1) + imageid) UploadDocs,
'Batch uploaded successfully on ' + CONVERT(varchar, max(ftpstime), 1) LastUploadDateTime 
--into xRMN_20220228xsxx
from document where RMN in (
'376VB0201225492E',
'376VB0201226222E',
'376VB0202226321E',
'376VB0224222629E',
'376VB0401225727E',
'376VB0421221709E',
'376VB0426221921E',
'376VB0426221978E',
'376VB0426222029E',
'376VB0427222013E',
'376VB0427222074E',
'376VB0427222166E',
'376VB0428222173E')
group by pbatch, rmn
order by RMN

select * from stats where kbatch = '02213351726601'

--�	376VB0217229322E
--�	376VB0217229324E
--�	376VB0217229585E
--�	376VB0217229481E
--�	376VB0217229583E
--�	376VB0217229323E
--�	376VB0217229325E
--�	376VB0217229563E


select distinct pbatch from PbatchDCSMapping where rmn in (
'376VB0201225492E',
'376VB0201226222E',
'376VB0202226321E',
'376VB0224222629E',
'376VB0401225727E',
'376VB0421221709E',
'376VB0426221921E',
'376VB0426221978E',
'376VB0426222029E',
'376VB0427222013E',
'376VB0427222074E',
'376VB0427222166E',
'376VB0428222173E')


select * from xRMN_20220228xsxx
where Docs <> UploadDocs


--DocId does not exist: 01260
select * from docid.dbo.docid where doctype like '%0998%'
--28-0957 - Vocational Rehabilitation Guidelines and Debt Prevention

--DocID	DocType
--1246	VRE Correspondence
--VA Form 28-0795 Vocational Rehabilitation and Employment (VR&E) Business Plan Review Guide


select * from PbatchDCSMapping where pbatch = '02212801904203'
select * from customerCheckIn where rmn = '376VB0614183627D'
select * from manifestDCS where rmn = '376VB0614183627D'
select * from PhysicalBatch where rmn = '376VB0614183627D'
select * from manifestDCS where pbatch = '022118018113'
select * from document where pbatch = '02220681801605' and ftpstime is null
select * from document where dcsid = 'KKSB1QFS1ZYNO0'


--update document
--set ftpstime = null
--where dcsid = 'KKSB1QFS1ZYNO0'
--and imageid = 'CSRA_210473104Q001010374'

and DCSIDComplete = 1
--Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC [CSRA_213273106Q001006886]
update document
set docidDoctype = 'VRE Correspondence'
where docidDoctype = '28-0957 - Vocational Rehabilitation Guidelines and Debt Prevention'
and ftpstime is null
and pbatch = '02211301001807'

update document
set docidDoctype = 'VA Form 20-0998 Your Right to Seek Further Review of Our Decision'
where docidDoctype = 'VA Form 20-0998 Your Rights to Seek Further Review of Our Decision'
and ftpstime is null
and pbatch = '02211251802904'

select * from customerCheckIn where trackingno = '1ZA46R390390128212'
select * from customerCheckIn where rmn = '376VB1109208212E'
select * from manifestDCS where rmn = '376VB1109208212E'
select * from PbatchDCSMapping where rmn = '376VB1109208212E'
--1ZA46R390390128212
--1ZA46R390390128212


--update Document
--set DCSIDComplete = 0
--where dcsid = 'KPRAB9SFPNGM0Q'
--and DCSIDComplete = 1


select * into dvarp.dbo.document_KSF80XDISKX7G8_02212321001412
--delete from PbatchDCSMapping where pbatch = 'x02212321001412'


--Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber (C20283627) [CSRA_211623103Q001026601]

update document
set DCSIDComplete = 0
where dcsID = 'KOBO0G19-D8ASAF'

select distinct pbatch from document where rmn = '376VB0910211056E' and ftpstime is null
select distinct pbatch  from PbatchDCSMapping where rmn = '376VB0910211056E' and ftpstime is null
select * from document where pbatch = '02211471804904'
--376VB0614183627D
--C20283627
--Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber (C20283627) [CSRA_211623103Q001026601]
select * from stats where kbatch = '02220101869102'
select * from document where dcsid = 'KUY5DVG3-QR0QHN'
select * from CustomerDATA where dcsid = 'KUY5DVG3-QR0QHN'
select * from PbatchDCSMapping where dcsid = 'KUY5DVG3-QR0QHN'
select max(ftpstime) from document where rmn = '376VB0524218080A'
select * from document where rmn = '376VB0910211056E' and ftpstime = '2021-10-14 15:57:49.860'
select * from customerCheckIn where rmn = '376VB0716218972E'
select * from PhysicalBatch where rmn = '376VB0716218972E'
select * from manifestDCS where rmn = '376VB0716218972E'

--Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC [CSRA_211603108Q001009522]
select * from document where pbatch in (
'02211391001302',
'02211331202703',
'02211331006310',
'02211331202906',
'02211331006114',
'02211331004915',
'02211371004903',
'00221251803107')

select distinct d.pbatch, d.rmn, max(d.ftpstime) 
from document d
where rmn in (
'339VB0428215252G',
'339VB0428213234G',
'376VB0119210155A',
'438VB0115214400A',
'316VB0428219585D',
'328VB0513212128B',
'316VB0427210489D',
'376VB0525218975A',
'346VB0408218352H',
'376VB0518219412A',
'316VB0525213386D') and d.ftpstime is  null
group by pbatch, rmn
order by pbatch, rmn


select distinct pbatch, rmn from document where rmn in (
'316VB0602218941D',
'376VB0512211957A',
'376VB0512212454A',
'376VB0519214060A',
'376VB0524218080A')
and ftpstime is null

--00221371003702
select * from document where pbatch = '02212701000601'
select * from document where rmn = '316VB0602218941D'

select * from document where dcsid = 'KTUAZXNG-MRP60K'
--Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC [CSRA_211603108Q001017368]


update document
set FileNumber = '251312467'
where FileNumber = '351312467'
and dcsid = 'KU8DLQOV1MUQZN'
and pbatch = '02212791929901'

update CustomerDATA
set FileNumber = '251312467'
where FileNumber = '351312467'
and dcsid = 'KU8DLQOV1MUQZN'
and pbatch = '02212791929901'


select * from stats where kbatch = '02212631804704'

update document
set ftpstime = '2021-10-14 15:57:50.863'
where ImageID = 'CSRA_212873109Q021024251'

select * from document where imageid = 'CSRA_212143109Q021018496'


update document
set NumPages = 814
where imageid = 'CSRA_212663105Q001034840'



select count(distinct pbatch) from document where RMN in (
'376VB0217229322E',
'376VB0217229324E',
'376VB0217229585E',
'376VB0217229481E',
'376VB0217229583E',
'376VB0217229323E',
'376VB0217229325E',
'376VB0217229563E')

select * from PbatchDCSMapping p where RMN in (
'376VB0217229322E',
'376VB0217229324E',
'376VB0217229585E',
'376VB0217229481E',
'376VB0217229583E',
'376VB0217229323E',
'376VB0217229325E',
'376VB0217229563E')
and not exists (select * from document where p.Pbatch = Pbatch)

select * from document where pbatch = '02220541449501'
select * from stats where kbatch = '02220541449501'
select * from PhysicalBatch where pbatch = '02220541449501'