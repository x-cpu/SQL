use dva	
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].document 
where dcsid = 'LJ7BKE647O1A2M'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].PbatchDCSMapping 
where dcsid = 'LJ7BKE647O1A2M'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].CustomerDATA 
where dcsid = 'LJ7BKE647O1A2M'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].manifestDCS 
where dcsid = 'LJ7BKE647O1A2M'

select * from [lon-va-sql-1\p1,2001].[dva].[dbo].customerCheckIn
where rmn = '376VB0622237980E'

select * from [lon-va-sql-1\p1,2001].[dva].[dbo].customerCheckIn
where rmn = '376VB0330237980E'

select max(syskey) from [lon-va-sql-1\p1,2001].[dva].[dbo].customerCheckIn

insert into [lon-va-sql-1\p1,2001].[dva].[dbo].customerCheckIn
(syskey, trackingno, RMN, insertdate, operID, location, destination,
claimtype, returnshippinglocation, boxSource, boxtype, fssOperID, 
ctop, returnLabelNo,
boxOrigin) VALUES ('555295','M0000037980','376VB0622237980E',
'2023-04-04 08:45:01.000',
'ExelaAuto','166','3',
'OMPF','NULL','FCS','OMPF','NULL',
'NULL','NULL','FCS')


select max(syskey) from [lon-va-sql-1\p1,2001].[dva].[dbo].customerCheckIn


update [lon-va-sql-1\p1,2001].[dva].[dbo].document 
set FileNumber = '09993391', dcsid = 'LJ7BKE647O1A2M'
,
RMN = '376VB0622237980E'
where dcsid = 'LFVB32RKHJQK2F'
and pbatch = '02231005006104'
and imageid in (
'CSRA_231024101Q001001781')

update [lon-va-sql-1\p1,2001].[dva].[dbo].PbatchDCSMapping 
set dcsid = 'LJ7BKE647O1A2M'
,
RMN = '376VB0622237980E'
where dcsid = 'LFVB32RKHJQK2F'
and pbatch = '02231005006104'

update [lon-va-sql-1\p1,2001].[dva].[dbo].PhysicalBatch 
set RMN = '376VB0622237980E'
where pbatch = '02231005006104'

update [lon-va-sql-1\p1,2001].[dva].[dbo].CustomerDATA 
set FileNumber = '09993391', dcsid = 'LJ7BKE647O1A2M',
Firstname = 'MICHAEL', MiddleInitial = '', Lastname = 'GRECO'
,
RMN = '376VB0622237980E', participantID = ''
where dcsid = 'LFVB32RKHJQK2F'
and pbatch = '02231005006104'

update [lon-va-sql-1\p1,2001].[dva].[dbo].manifestDCS 
set dcsid = 'LJ7BKE647O1A2M'
,
RMN = '376VB0622237980E'
where dcsid = 'LFVB32RKHJQK2F'
and pbatch = '022310050061'


select distinct d.imageid + '|' + d.pbatch + '|' + d.dcsid + '|' + d.FileNumber + '|' 
+ RIGHT('00'+ISNULL(dd.DocID,''),5) + '|' + c.firstname + '|' + c.MiddleInitial + '|' 
+ c.Lastname + '|' + d.received_date + '|' + CONVERT(varchar(10), d.numpages) + '|'
+ '06/28/2023 9:19:15 AM' 
+ '|' + '06/28/2023 9:19:15 AM' 
+ '|' + d.PBatch + '\' +  d.imageid + '.pdf' + '|' +
	CASE
		When cc.claimtype = 'C' Then 'C' + '|' + '|' + '|' + d.RMN + '|' 
		When cc.claimtype <> 'C' Then 'P' + '|' + '|' + '|' + d.RMN + '|' 
		End claimtype
from [lon-va-sql-1\p1,2001].[dva].[dbo].document d
left join [lon-va-sql-1\p1,2001].docid.dbo.docid dd
on d.docidDoctype = dd.doctype
left join [lon-va-sql-1\p1,2001].[dva].[dbo].CustomerDATA c
on d.dcsid = c.dcsid
left join [lon-va-sql-1\p1,2001].[dva].[dbo].customerCheckIn cc
on d.rmn = cc.RMN
where d.ImageID = 'CSRA_231024101Q001001781' and d.pbatch = '02231005006104'

update [lon-va-sql-1\p1,2001].[dva].[dbo].document
set ftpstime = null, Comments = null, MA18doctype = 'UPDATEDOCUMENT001', OrgID = 'PDFONLY'
where ImageID in (
'CSRA_231024101Q001001781')
