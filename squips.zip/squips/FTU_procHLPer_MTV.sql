select * from document where dcsid = 'L38VRXR4PX3IP7'
select * from pbatchdcsmapping where dcsid = 'L38VRXR4PX3IP7'
select * from CustomerDATA where dcsid = 'L6QH5I1S-QIK8N1'
select * from document where imageid = 'CSRA_213193109Q001011386'

--update document
--set NumPages = 9
--where imageid = 'CSRA_213213105Q001008625'


--update document
--set DCSID = 'L77WZQPI-5URA7P'
--where dcsid = 'KVK5WZ9CHAHF5H'
--and pbatch = '02213131759309'

--update PbatchDCSMapping
--set DCSID = 'L77WZQPI-5URA7P'
--where dcsid = 'KVK5WZ9CHAHF5H'
--and pbatch = '02213131759309'

--update CustomerDATA
--set DCSID = 'L77WZQPI-5URA7P'
--where dcsid = 'KVK5WZ9CHAHF5H'
--and pbatch = '02213131759309'

select * from stats where kbatch = '02221731209019'
--KVL1UP7KHICEVQ
--update document
--set ftpstime = null
--where dcsid = 'L2HE5JGM-12VGCZ'

--update document
--set FileNumber = '542422418'
--where dcsid = 'L77WZQPI-5URA7P'
--and pbatch = '02213131759309'

--update CustomerDATA
--set FileNumber = '542422418'
--where dcsid = 'L77WZQPI-5URA7P'
--and pbatch = '02213131759309'

--CSRA_221993104Q001001310
--CSRA_221993108Q001005022
--CSRA_213193109Q001011386

--update document
--set NumPages = 90
--where imageid = 'CSRA_213093105Q001009382'

select * from dvarp.dbo.[document_L10RIZ08-9HKUUJ]

select * from document where imageid = 'CSRA_222563108Q001005360'
select * from docid.dbo.docid where doctype like '%0791%'

update document
set docidDoctype = 'VA Form 28-0791, Preliminary Independent Living (IL) Assessment'
where imageid = 'CSRA_222563108Q001005360'

select *
into dvarp.dbo.[document_L5I5H2UZ-8V6TTO]
from document where dcsid = 'L5I5H2UZ-8V6TTO'

select distinct dcsid, filenumber, 
'561572588' newfilenumber,
pbatch, imageid
from document 
where imageid in (
'CSRA_230173102Q001003617',
'CSRA_230173102Q001003618')

--by dcsid
select distinct dcsid, filenumber, 
filenumber newfilenumber,
pbatch, imageid
from document 
where dcsid = 'L3D826K1ALB3IL'

select distinct imageid, pbatch
from document 
where imageid in (
'CSRA_230173102Q001003617',
'CSRA_230173102Q001003618')
order by ImageID

--by dcsid
select distinct imageid, pbatch
from document 
where dcsid = 'L3D826K1ALB3IL'
order by ImageID


select *
from document 
where imageid in (
'CSRA_230133104Q001001635')


--by dcsid
select *
from document 
where dcsID in (
'L5I5H2UZ-8V6TTO')


select * from CustomerDATA where dcsid = 'L5I5H2UZ-8V6TTO'