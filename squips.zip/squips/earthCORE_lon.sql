select * from [lon-va-sql-1\p1,2001].[dva].[dbo].PhysicalBatch
where invtime >= '2023-04-26'
--OMPFCorr

select * from [lon-va-sql-1\p1,2001].[dva].[dbo].PhysicalBatch 
where pbatch like '022314505038%'

update [lon-va-sql-1\p1,2001].[dva].[dbo].PhysicalBatch
set cordest = 'OMPFCorr'
where pbatch like '022314505038%'


--02231095801901
--02231095801902
--02231095801903
--02231095801904
--02231095801905
--02231095801906
--02231095801907
--02231095801908

