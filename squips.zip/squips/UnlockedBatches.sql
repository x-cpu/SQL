select u.username, w.WSName, a.* from Audit a, Users u, WorkStations w
where a.UserID = u.UserID
and a.WSID = w.WSID
and a.EventComment = 'Unlock Batch'
