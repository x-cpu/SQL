select d.dcsid, x.newfilenumber newFileNumber, d.FileNumber,
d.pbatch, d.ImageID orgImageID, x.imageid, d.ftpstime, d.OrgID, d.MA18doctype
--into xrmcftu20210730
from xrmcftu20210722 x
left join document d
on x.imageid = d.ImageID
where newfilenumber not LIKE '%[^0-9]%'
--and orgid is not null
order by d.PBatch, d.dcsid, x.imageid

--can't be processed
select d.dcsid, x.imageid, x.newfilenumber [File Number to Upload to:]
--x.newfilenumber newFileNumber, d.FileNumber,
--d.pbatch, d.ImageID orgImageID, x.imageid, d.ftpstime, d.OrgID, d.MA18doctype
--into xrmcftu20210730
from xrmcftu20210722 x
left join document d
on x.imageid = d.ImageID
where newfilenumber  LIKE '%[^0-9]%'
--and orgid is not null
order by d.PBatch, d.dcsid, x.imageid

select * from xrmcftu20210730

select x.dcsID, FileNumber, newFileNumber, PBatch, ImageID 
from xrmcftu20210730 x
where dcsid is not null	
order by pbatch, ImageID

select ImageID, PBatch
from xrmcftu20210730 x
where dcsid is not null	
order by pbatch, ImageID


select d.dcsid, 
--x.newfilenumber newFileNumber, d.FileNumber,
--d.pbatch, d.ImageID orgImageID, 
x.imageid, xx.orgid orgidx, xx.ftpstime orgFTPstime, d.ftpstime
--, d.ftpstime, d.OrgID, d.MA18doctype
--into xrmcftu20210730
into xrmcftu20210730x
from xrmcftu20210722 x
left join document d
on x.imageid = d.ImageID
left join xrmcftu20210730 xx
on x.ImageID = xx.imageid	
where x.newfilenumber NOT LIKE '%[^0-9]%'
--and orgid is not null
and d.ftpstime >= '2021-07-30'
order by orgidx, x.imageid

--select * from xrmcftu20210722


select x.dcsID, FileNumber, newFileNumber, PBatch, ImageID, ftpstime
from xrmcftu20210730 x
where dcsid is not null	and pbatch like '02%'
order by pbatch, ImageID

select x.dcsID, ImageID
from xrmcftu20210730 x
where dcsid is not null	and pbatch like '02%'
order by pbatch, ImageID

select * from xrmcftu20210730x

--update d
--set d.ftpstime = x.orgFTPstime
--from document d
--left join xrmcftu20210730x x
--on d.ImageID = x.imageid
----where x.imageid = 'CSRA_190713102P001037001'
--where x.imageid = d.ImageID

select * from document where imageid = 'CSRA_190713102P001037001'
select * from xrmcftu20210730x where imageid = 'CSRA_190713102P001037001'