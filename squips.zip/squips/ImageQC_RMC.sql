select sum(userimagesprocessed), sum(UserProcTime)
from TS_Audit t
where t.TimeStamp >= '2021-03-10'
and t.timestamp < '2021-03-11'
and t.batchname like '01%'
and t.tsmodule = 'ImageQC'

select * 
from TS_Audit t
where t.TimeStamp >= CAST(getdate() AS DATE)
and UserImagesProcessed > 0 and UserProcTime is not null
order by UserProcTime