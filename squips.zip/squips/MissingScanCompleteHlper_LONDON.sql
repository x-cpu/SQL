--identify the good ones template
select distinct Y.dcsid,
CASE
	WHEN Y.cBatches = Y.eBatches
	and Y.Docs = Y.xTimes
	Then 'Matching'
	Else null
	End Status
	into xdcsid_20230605lon_matchingxx02
FROM
(select distinct X.dcsid,
X.cBatches,
count(distinct d.PBatch) eBatches,
count(distinct d.imageid) Docs,
count(distinct CONVERT(varchar, d.ftpstime,1) + imageid) xTimes
FROM
(select distinct x.dcsid dcsid, count(distinct p.pbatch) cBatches
from xdcsid_20230605lon x
left join [lon-va-sql-1\p1,2001].dva.dbo.PbatchDCSMapping p
on x.dcsid = p.dcsid
where p.Pbatch not like '%test%'
group by x.dcsid) X
left join [lon-va-sql-1\p1,2001].dva.dbo.document d
on X.dcsid = d.dcsID
where d.ftpstime is not null
group by X.dcsid,
X.cBatches) Y

--trying to finalize for mass update
select distinct T.ImageID imageId, T.dcsID dcsid, 
count(distinct d.imageid) totalPDFs
--into xDCSIDS20220425xxx02
FROM
(select distinct d.ImageID, PBatch, T.dcsID, d.newimageid
FROM
(select distinct dcsid, max(ftpstime) UploadDateTime from [lon-va-sql-1\p1,2001].dva.dbo.document where dcsid in (
select distinct dcsID from xdcsid_20230605lon_matchingxx02
where status = 'matching')
and filesize <> 0
and len(newimageid) < 2
group by dcsid) T
left join [lon-va-sql-1\p1,2001].dva.dbo.document d
on T.UploadDateTime = d.ftpstime
and T.dcsID = d.dcsID) T
--order by pbatch desc
left join [lon-va-sql-1\p1,2001].dva.dbo.document d
on T.dcsID = d.dcsID
group by T.ImageID, T.dcsID
order by T.dcsID



select distinct dcsid
into xdcsid_20230605lon
from [lon-va-sql-1\p1,2001].[dva].[dbo].[pbatchdcsmapping]
where dcsid in (
'LHJC1SGZ-N7UCUY',
'LHGF3TCY33O536',
'LHJAN0PGCHTBLF',
'LHHLCCUZ-M35CV0',
'LHIGQCKT-X02MZH',
'LHJR2ZWW3TZCFO',
'LHJBW8B1-T2R6PZ',
'LHIDL9SDJTE0C5')