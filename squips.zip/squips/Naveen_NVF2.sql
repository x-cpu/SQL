--C10185233 & C10366569

select distinct p.RMN,
c.FileNumber,
s.dcsid DCSID,
s.ackTime [DMHS update Date],
--pp.InvTime [Received Date],
UPPER(c.Firstname) Firstname,
UPPER(c.Lastname) Lastname,
UPPER(c.MiddleInitial) MiddleInitial
into x20210331
from smsDCSMapping s
left join PhysicalBatch p
on s.batchname = p.PBatch
left join CustomerDATA c
on s.dcsid = c.dcsID
--left join [mtv-va-sql-1\p922].dva.dbo.physicalbatch pp
--on p.RMN = pp.RMN
where s.ackTime is not null
and exists (select * from PhysicalBatch where s.batchname = pbatch and  rmn in (
'C10185233', 'C10366569'))