--713 with distinct imageid
select distinct imageid from document_OMPF_part12
select distinct dcsid from document_OMPF_part12
select distinct imageid, len(imageid) from document_OMPF_part12
order by len(imageid)
where len(docidDoctype) > 1
--16372 is total docs to be processed
--16361 valid imageid
select distinct ImageID,
NumPages, docidDocType
---, insertDate
from document_OMPF_part12
where len(docidDoctype) > 1

--insert this into a sep table
--this is last doc type ever selected
--358
select distinct x.ImageID,
t.numpages, t.docidDocType
into xOMPF_part12wDocTypes
FROM
(select distinct ImageID, 
max(insertdate) InsertDate 
from document_OMPF_part12
where len(docidDoctype) > 1
group by ImageID) x
left join document_OMPF_part12 t
on x.imageid = t.imageid and x.InsertDate = t.insertdate
order by ImageID

--358
select distinct ImageID, 
numpages, docidDoctype
from document_OMPF_part12
where (dociddoctype is null or dociddoctype = '')
--573

select distinct docidDoctype from document_OMPF_part11 where len(imageid) <= 24

select T.* into document_OMPF_part12x
FROM
(select distinct imageid, numpages, 'docidDocType' = null
from document_OMPF_part12 
where (dociddoctype is null or dociddoctype = '')
and imageid not in (select distinct imageid from xOMPF_part12wDocTypes)
union
select * from xOMPF_part12wDocTypes) T

select distinct d.imageid, d.pbatch 
from document_OMPF_part12x x
left join document d
on x.imageid = d.imageid
order by d.pbatch, d.imageid

select * from document_OMPF_part12 where len(imageid) > 24
select * from document_OMPF_part12x where len(imageid) > 24

select * from document_OMPF_part11x
-- 5325
--11047
--16372

select * 
from document
where exists (select * from document_OMPF_part11 where document.imageid = imageid)
and not exists (select * from xOMPF1605 where document.imageid = imageid)
and len(imageid) <25

update d
set OrgID = 'PDFONLY', MA18doctype = 'UPDATEDOCUMENT001', ftpstime = null
from document d
where exists (select * from document_OMPF_part11 where d.imageid = imageid)
and not exists (select * from xOMPF1605 where d.imageid = imageid)
and len(imageid) <25

update d
set ftpstime = null
from document d
where exists (select * from document_OMPF_part11 where d.imageid = imageid)
and not exists (select * from xOMPF1605 where d.imageid = imageid)
and len(imageid) >25

select * into dvarp.dbo.document_OMPF_part12_orgDoc from document
where exists (select * from document_OMPF_part12 where document.pbatch = pbatch)

select distinct imageid, pbatch, orgid, ftpstime, MA18doctype 
--into xOMPF1605
from document 
where exists (select * from document_OMPF_part11x where document.imageid = imageid)
and ftpstime >= '2021-05-01'
order by ftpstime desc

select distinct pbatch from document 
where not exists (select * from document_OMPF_part11x where document.imageid = imageid)
and ftpstime >= '2021-05-01'
order by ftpstime desc

select distinct pbatch from document
where not exists (select * from xOMPF1605 where document_OMPF_part11x.imageID = imageid)
and exists (select * from document_OMPF_part11x where document.imageID = imageid)


select distinct imageid, pbatch, orgid, ftpstime, MA18doctype from document
where exists (select * from document_OMPF_part11x where document.imageid = imageid)
and ftpstime >= '2021-05-01'
order by ftpstime desc