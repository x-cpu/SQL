select distinct DATEPART(hour, ftpstime) Hr, 
sum(numpages) TotalImages
from [lon-va-sql-1\p1,2001].[dva].[dbo].document
where ftpstime >= '2023-06-07'
group by DATEPART(hour, ftpstime)


--L1F120UINK9URQ
--L1F13EDU-B57QJT
--L1F14NHZQOK38I

update [lon-va-sql-1\p1,2001].[dva].[dbo].document 
set DCSIDComplete = 1
where imageid = 'CSRA_230594101Q001009492'

select distinct pbatch  from [lon-va-sql-1\p1,2001].[dva].[dbo].pbatchdcsmapping
where RMN = '376VB0406239127E'
order by dcsid


update [lon-va-sql-1\p1,2001].[dva].[dbo].CustomerDATA 
set Lastname = 'HICKEY'
where dcsid = 'LE7BH16X-DC9WRX'

update [lon-va-sql-1\p1,2001].[dva].[dbo].document 
set FileNumber = '421383591'
where dcsid = 'LEPOCFLLQ00V7F'

update [lon-va-sql-1\p1,2001].[dva].[dbo].customerdata 
set FileNumber = '421383591'
where dcsid = 'LEPOCFLLQ00V7F'

use dva	
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].document 
where dcsid = 'LHJ6K1CQBVS8SF'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].PbatchDCSMapping 
where dcsid = 'LHJ6K1CQBVS8SF'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].CustomerDATA 
where dcsid = 'LHJ6K1CQBVS8SF'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].manifestDCS 
where dcsid = 'LGXZJAEN-KYZ8FD'
select *  from [lon-va-sql-1\p1,2001].[dva].[dbo].physicalbatch 
where rmn = 'LG450J5G5B84QL'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].manifestDCS 
where dcsid = 'LFTQ070GZDHAHB'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].customerCheckIn where RMN = '376VB0217236634E'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].customerCheckIn where RMN = '376VB0201233427E'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].manifestDCS where RMN = '376VB0201233427E'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].PhysicalBatch where RMN = '376VB0201232665E'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].document where RMN = '376VB0201233427E'   
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].customerCheckIn where trackingno = 'M0000036634'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].manifestdcs where trackingno = 'M0000036634'
select distinct pbatch from [lon-va-sql-1\p1,2001].[dva].[dbo].PbatchDCSMapping where RMN = '376VB0520225588A'

select * from [lon-va-sql-1\p1,2001].[dva].[dbo].FTPError where imageid = 'CSRA_230464101Q001011649'

select * from Stats_IBML where kbatch like '022311505034%'

select * from [lon-va-sql-1\p1,2001].[dva].[dbo].PhysicalBatch_bck 
where pbatch like '022311505034%'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].pbatchdcsmapping_bck
where pbatch like '022311505034%'

--void deleted batch check
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].PhysicalBatch_Void 
where pbatch like '022311505034%'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].pbatchdcsmapping_void
where pbatch like '022311505034%'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].manifestdcs_void 
where pbatch like '022311505034%'

select * from [lon-va-sql-1\p1,2001].[dva].[dbo].PhysicalBatch_Void 
order by VoidDate desc



--update [lon-va-sql-1\p1,2001].[dva].[dbo].document 
--set FileNumber = '554312853'
--where dcsid = 'L3EJ3MO7-BBN6W1'

--update [lon-va-sql-1\p1,2001].[dva].[dbo].customerdata 
--set FileNumber = '554312853'
--where dcsid = 'L3EJ3MO7-BBN6W1'

--update [lon-va-sql-1\p1,2001].[dva].[dbo].document
--set FileNumber = '215345662', dcsid = 'LG453T8Q-1QX17W'
--where imageid in (
--'CSRA_231194101Q001000178',
--'CSRA_231194101Q001000179')

select * from [lon-va-sql-1\p1,2001].[dva].[dbo].manifestDCS where dcsid = 'LE8KE95P-Z8Q2AE'
															   
update [lon-va-sql-1\p1,2001].[dva].[dbo].CustomerDATA
set Lastname = 'J'
where dcsid = 'LG540BEH-KJQNJZ'

select max(syskey) from CustomerDATA

--update document
--set NumPages = 1
--where imageid = 'CSRA_221393108Q001000921'

select * from [lon-va-sql-1\p1,2001].[dva].[dbo].pbatchdcsmapping 
where pbatch = '02230945000709' 


--delete from [lon-va-sql-1\p1,2001].[dva].[dbo].document where pbatch = '02223185303001'
--delete from [lon-va-sql-1\p1,2001].[dva].[dbo].pbatchdcsmapping 
--where Pbatch = '02230285600301'
--Status Code: 426 - Response Error: FCS File Number and/or DCSID not found [CSRA_231314101Q001003770]
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].document 
where pbatch = '02230935013404'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].stats 
where kbatch = '02230935013404'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].pbatchdcsmapping 
where Pbatch = '02231215701608'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].physicalbatch 
where Pbatch = '02231215603701'
select * from [lon-va-sql-1\p1,2001].[dva].[dbo].stats_ibml 
where kbatch = '02231445006517'

select * from [lon-va-sql-1\p1,2001].[dva].[dbo].stats_ibml 
where kbatch in (
'02231445006517',
'02231445006903',
'02231445006911',
'02231455004314',
'02231465010201')

select * from [lon-va-sql-1\p1,2001].TURBOSCANNG_OCR1.dbo.batches where batchname = '02231095108512'
select * from [lon-va-sql-1\p1,2001].TURBOSCANNG_OCR2.dbo.batches where batchname = '02231095108512'
select * from [lon-va-sql-1\p1,2001].TURBOSCANNG_OCR3.dbo.batches where batchname = '02231095108512'
select * from [lon-va-sql-1\p1,2001].TURBOSCANNG_OCR4.dbo.batches where batchname = '02231095108512'
select * from [lon-va-sql-1\p1,2001].TURBOSCANNG_OCR5.dbo.batches where batchname = '02231095108512'



update [lon-va-sql-1\p1,2001].TURBOSCANNG_OCR1.dbo.batches
set Priority = 1
where batchname = '02231095108512'





select distinct d.imageid + '|' + d.pbatch + '|' + d.dcsid + '|' + d.FileNumber + '|' 
+ RIGHT('00'+ISNULL(dd.DocID,''),5) + '|' + c.firstname + '|' + c.MiddleInitial + '|' 
+ c.Lastname + '|' + d.received_date + '|' + CONVERT(varchar(10), d.numpages) + '|'
+ '05/22/2023 9:19:15 AM' 
+ '|' + '05/22/2023 9:19:15 AM' 
+ '|' + d.PBatch + '\' +  d.imageid + '.pdf' + '|' +
	CASE
		When cc.claimtype = 'C' Then 'C' + '|' + '|' + '|' + d.RMN + '|' 
		When cc.claimtype <> 'C' Then 'P' + '|' + '|' + '|' + d.RMN + '|' 
		End claimtype
from [lon-va-sql-1\p1,2001].[dva].[dbo].document d
left join [lon-va-sql-1\p1,2001].docid.dbo.docid dd
on d.docidDoctype = dd.doctype
left join [lon-va-sql-1\p1,2001].[dva].[dbo].CustomerDATA c
on d.dcsid = c.dcsid
left join [lon-va-sql-1\p1,2001].[dva].[dbo].customerCheckIn cc
on d.rmn = cc.RMN
where d.ImageID = 'CSRA_231284101Q001002033' and d.pbatch = '02230470900201'

--update [lon-va-sql-1\p1,2001].[dva].[dbo].document
--set ftpstime = null, Comments = null, MA18doctype = 'UPDATEDOCUMENT001', OrgID = 'PDFONLY'
--where ImageID in (
--'CSRA_231284101Q001002033')

select * from [lon-va-sql-1\p1,2001].[dva].[dbo].document where dcsid in (
'LGGL2KDX-JWC5BM',
'LGM68K7J-5KSBXM',
'LGP6HXE9EV5JC0',
'LGGM7AHQ3X4X96')
and ftpstime is null
