select * from [lon-va-sql-1\p1,2001].[dva].[dbo].document 
where Comments like 'Status Code: 5%'
and ftpstime is null
and imagedatetime >= '2022-01-01'
order by PBatch

select distinct pbatch 
from [lon-va-sql-1\p1,2001].[dva].[dbo].document 
where Comments like 'Status Code: 426 - Response Error: FCS File Number%'
and ftpstime is null
and ImageDateTime >= '2022-01-01'

select *
from [lon-va-sql-1\p1,2001].[dva].[dbo].document 
where Comments like 'Status Code: 426 - Response Error: FCS File Number%'
and ftpstime is null
and ImageDateTime >= '2022-01-01'

select distinct dcsID 
from [lon-va-sql-1\p1,2001].[dva].[dbo].document 
where Comments like 'Status Code: 426 - Response Error: FCS File Number%'
and ftpstime is null
and ImageDateTime >= '2022-01-01'

select distinct PBatch, imageid 
from [lon-va-sql-1\p1,2001].[dva].[dbo].document 
where Comments like '%chilkat%'
and ftpstime is null
and ImageDateTime >= '2022-01-01'
order by pbatch

select distinct PBatch 
from [lon-va-sql-1\p1,2001].[dva].[dbo].document 
where Comments like '%chilkat%'
and ftpstime is null
and ImageDateTime >= '2022-01-01'

select * 
from [lon-va-sql-1\p1,2001].[dva].[dbo].document 
where Comments is null
and ftpstime is null
and OCRExportTime is not null
and ImageDateTime >= '2022-01-01'
order by ImageDateTime

select * from document 
where Comments is not null
and ftpstime is null
and OCRExportTime >= '2023-01-17'
and ImageDateTime >= '2022-01-01'
order by ImageDateTime

select * from document where pbatch = '02221541305410'
select * from customerCheckIn where rmn = '376VB0426222358E'
select * from customerCheckIn where rmn in (
'362VB0520171887H',
'328VB0804177703B',
'316VB0628174696D',
'335VB1017174148A')

select * from document
where ftpstime is not null
and ftpstime >= '2022-01-01'
and exists (select * from customerCheckIn where document.rmn = rmn
and boxSource = 'fss' and boxtype = 'cxc')

select distinct boxsource, boxType
from customerCheckIn 
where exists (select * from document where customerCheckIn.rmn = rmn
and ftpstime >= '2022-01-01')

select * from document 
where Comments is null
and ftpstime is null
and OCRExportTime is not null
and ImageDateTime >= '2022-03-30'
and ImageDateTime < '2022-08-29'
order by ImageDateTime
 