select distinct 
RTRIM(c.RMN) RMN,
c.trackingno TrackingNo, 
p.PBatch BatchName, 
p.BatchClassName,
s.kbatch ExportedBatchName,
m.dcsid DCSID
--d.ImageID,
--d.ftpstime
from customerCheckIn c
left join PhysicalBatch p
on c.RMN = p.RMN
left join stats s
on p.PBatch = s.kbatch
--left join document d
--on p.PBatch = d.PBatch
left join PbatchDCSMapping m
on c.RMN = m.RMN
where p.PBatch like '02%'
and p.InvTime >= '2020-06-01'
and c.trackingno is not null
and c.trackingno <> ''
and c.trackingno <> '1234DUMMY1234'
and c.claimtype = 'ompf'
group by c.trackingno, RTRIM(c.RMN),
p.PBatch, p.BatchClassName, s.kbatch,
m.dcsid
--d.ImageID, d.ftpstime


select distinct BatchClassName, count(*) 
from PhysicalBatch p
where exists (select * from customerCheckIn where claimtype = 'ompf' and p.RMN = rmn)
and p.PBatch like '02%'
and p.InvTime >= '2020-06-01'
group by BatchClassName
