select distinct d.pbatch, c.claimtype
from document d
left join PhysicalBatch p
on d.PBatch = p.PBatch
left join customerCheckIn c
on p.RMN = c.RMN
where d.ftpstime >= '2021-03-10'
and d.PBatch like '02%'