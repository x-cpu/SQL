USE TURBOSCANNG1
select distinct X.CheckInDate,
--sum(X.Capture) + sum(X.Enhance1) + sum(X.FullPageOCR) ImageCount, 
sum(X.ImageCount) ImageCount,
sum(X.Capture) Capture, 
sum(X.Enhance1) Enhance1,
sum(X.FullPageOCR) FullPageOCR, 
sum(X.Enhance2) Enhance2, sum(X.Separation) Separation,
sum(X.ImageQC) ImageQC, sum(X.AutoIndex) AutoIndex, 
sum(X.DocID) DocID, sum(X.DocIDQC) DocIDQC,
sum(X.ManualIndex) ManualIndex, 
sum(X.Verification) Verification, 
sum(X.Export) Export, 
sum(X.Completed) Clean
FROM
(select distinct T.CheckInDate, ISNULL(sum(b.TotalImages), 0) ImageCount,
CASE 
	WHEN b.WFStep = 1 Then ISNULL(sum(b.TotalImages), 0)
	ELSE 0
	END Capture,
CASE 
	WHEN b.WFStep = 2 Then ISNULL(sum(b.TotalImages), 0)
	ELSE 0
	END Enhance1,
CASE 
	WHEN b.WFStep = 3 Then ISNULL(sum(b.TotalImages), 0)
	ELSE 0
	END FullPageOCR,
CASE 
	WHEN b.WFStep = 4 Then ISNULL(sum(b.TotalImages), 0)
	ELSE 0
	END Enhance2,
CASE 
	WHEN b.WFStep = 5 Then ISNULL(sum(b.TotalImages), 0)
	ELSE 0
	END Separation,
CASE 
	WHEN b.WFStep = 6 Then ISNULL(sum(b.TotalImages), 0)
	ELSE 0
	END ImageQC,
CASE 
	WHEN b.WFStep = 7 Then ISNULL(sum(b.TotalImages), 0)
	ELSE 0
	END AutoIndex,
CASE 
	WHEN b.WFStep = 8 Then ISNULL(sum(b.TotalImages), 0)
	ELSE 0
	END DocID,
CASE 
	WHEN b.WFStep = 9 Then ISNULL(sum(b.TotalImages), 0)
	ELSE 0
	END DocIDQC,
CASE 
	WHEN b.WFStep = 10 Then ISNULL(sum(b.TotalImages), 0)
	ELSE 0
	END ManualIndex,
CASE 
	WHEN b.WFStep = 12 and b.BatchLocation = 64 Then ISNULL(sum(b.TotalImages), 0)
	ELSE 0
	END Verification,
CASE 
	WHEN b.WFStep = 13 and b.BatchLocation = 256 Then ISNULL(sum(b.TotalImages), 0)
	ELSE 0
	END Export,
CASE 
	WHEN b.WFStep = 13 and b.BatchLocation = 0 Then ISNULL(sum(b.TotalImages), 0)
	ELSE 0
	END Completed
FROM
(select distinct CONVERT(varchar, p.invtime, 101) CheckInDate,
p.pbatch BatchName
from [mtv-va-sql-1\p922].dva.dbo.physicalbatch p with (NOLOCK)
where p.pbatch like '02%'
and exists (select * from [mtv-va-sql-1\p922].dva.dbo.customerCheckIn where
p.RMN = RMN and claimtype = 'OMPF') 
and p.invtime >= '2021-06-10') T 
left join Batches b
on T.BatchName = b.BatchName
where b.TotalImages is not null
and (b.WFStep = 1 or b.WFStep = 2 or b.WFStep = 3 or 
b.WFStep = 4 or b.WFStep = 5 or b.WFStep = 6 or 
b.WFStep = 7 or b.WFStep = 8 or b.WFStep = 9 or b.WFStep = 10 or
(b.WFStep = 12 and b.batchlocation = 64) or (b.WFStep = 13 and b.batchlocation = 256)
or (b.WFStep = 13 and b.batchlocation = 0))
and b.jobid = 8
and b.batchname like '02%'
and b.BatchName not like '%test%' 
and b.Batchname not like '%train%'
group by CheckInDate, b.WFStep, b.BatchLocation) X
group by X.CheckInDate
order by X.CheckInDate