select distinct pbatch 
from document where rmn = '317VB0624211521S'
and ftpstime is null

select distinct pbatch 
from PhysicalBatch where rmn = '317VB0624211521S'

select * from document where pbatch = '02211801001117'

--319VB0622210350D
--316VB0622213626D
--316VB0617215816D
--317VB0622215955S
--317VB0623217932S
--317VB0624216201S
--317VB0624211521S

select distinct RMN from document where rmn in (
'319VB0622210350D',
'316VB0622213626D',
'316VB0617215816D',
'317VB0622215955S',
'317VB0623217932S',
'317VB0624216201S',
'317VB0624211521S') and ftpstime is null