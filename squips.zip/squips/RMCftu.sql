select * from document where dcsid = 'JPMPU1YTG0L0VB'
select * from document where dcsid = 'JPMPU1YTGOL0VB'

--update document
--set dcsid = 'JPMPU1YTGOL0VB'
--where dcsid = 'JPMPU1YTG0L0VB'

--update CustomerDATA
--set dcsid = 'JPMPU1YTGOL0VB'
--where dcsid = 'JPMPU1YTG0L0VB'

select * from document where imageid = 'CSRA_183623105P001018846'

select * from document where imageid in (
'CSRA_191203103P011025720',--2021-08-06 10:48:17.653
'CSRA_191203103P021025720',
'CSRA_191203103P031025720')
--JPCWCFU6VW7J62
--JPCWCFU6VW7G62
select * from document where pbatch = '02200341013301'
select * from document where dcsid = 'JGPH1YE9-6BDYVW'
select * from customerCheckIn where rmn = '376VB0502183903D'
select * from CustomerDATA where dcsid = 'JPCWCFU6VW7J62'
--select * from customerCheckIn where rmn = '376VB1206187437D'

--update customerdata
--set dcsID = 'JPCWCFU6VW7G62'
--where dcsid = 'JPCWCFU6VW7J62'

--update document
--set dcsid = 'JPCWCFU6VW7G62'
--where dcsid = 'JPCWCFU6VW7J62'
--and imageid in (
--'CSRA_191203103P011025720',
--'CSRA_191203103P021025720',
--'CSRA_191203103P031025720')

select * from document where imageid in (
'CSRA_200413105P021007639',--2021-05-17 10:41:48.767
'CSRA_200413105P031007639',--2021-05-17 10:42:15.977
'CSRA_200413105P041007639',--2021-05-17 10:41:31.423
'CSRA_200413105P051007639')--2021-05-17 10:41:53.757
--JGPH1YE9-6BDYVW
--JGPH1YE9-6BDYVW
--02200341013301

--update document
--set DCSIDComplete = 1
--where imageid = 'CSRA_200413105P051007639'


--update document 
--set ftpstime = null
--where imageid in (
--'CSRA_200413105P021007639',--2021-05-17 10:41:48.767
--'CSRA_200413105P031007639',--2021-05-17 10:42:15.977
--'CSRA_200413105P041007639',--2021-05-17 10:41:31.423
--'CSRA_200413105P051007639')

--update document 
--set OrgID = 'PDFONLY'
--where imageid in (
--'CSRA_200413105P021007639',--2021-05-17 10:41:48.767
--'CSRA_200413105P031007639',--2021-05-17 10:42:15.977
--'CSRA_200413105P041007639',--2021-05-17 10:41:31.423
--'CSRA_200413105P051007639')

select * from document where imageid = 'CSRA_191203103P021025720'
select * from document where pbatch = '02191171102701'

select distinct d.imageid + '|' + d.pbatch + '|' + d.dcsid + '|' + d.FileNumber + '|' 
                                + RIGHT('00'+ISNULL(dd.DocID,''),5) + '|' + c.firstname + '|' + c.MiddleInitial + '|' 
                                + c.Lastname + '|' + d.received_date + '|' + CONVERT(varchar(10), d.numpages) + '|'
                                + '08/25/2021 9:19:15 AM' 
                                + '|' + '08/25/2021 9:19:15 AM' 
                                + '|' + d.PBatch + '\' +  d.imageid + '.pdf' + '|' +
								CASE
									When cc.claimtype = 'C' Then 'C' + '|' + '|' + '|' + d.RMN + '|' 
									When cc.claimtype <> 'C' Then 'P' + '|' + '|' + '|' + d.RMN + '|' 
									End claimtype
								from document d
                                left join docid.dbo.docid dd
                                on d.docidDoctype = dd.doctype
                                left join CustomerDATA c
                                on d.dcsid = c.dcsid
								left join customerCheckIn cc
								on d.rmn = cc.RMN
                                where d.ImageID = 'CSRA_183623105P001018846' and d.pbatch = '01183551834201'


select * from document where imageid in (
'CSRA_191203103P011025720',--2021-08-06 10:48:17.653
'CSRA_191203103P021025720',
'CSRA_191203103P031025720')

select * from document where dcsid = 'JPCWCFU6VW7G62'

--update document
--set ftpstime = null
--where imageid = 'CSRA_191203103P011025720'



--02191171102701

select * from document where pbatch = '02200341013301'

select * from document where dcsid = 'JPMPU1YTGOL0VB'

--update document
--set DCSIDComplete = 0
--where imageid = 'CSRA_183623105P001018846'

--update document
--set ftpstime = null
--where imageid = 'CSRA_183623105P001018846'