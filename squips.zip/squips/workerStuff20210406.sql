select distinct ImageID, PBatch, dcsID, d.RMN , c.trackingno
from document d
left join customerCheckIn c
on d.rmn = c.RMN
where ftpstime > '2021-04-01'
and exists (select * from PhysicalBatch where d.rmn = rmn
and exists (select * from customerCheckIn where PhysicalBatch.rmn = rmn 
and boxorigin = 'fcs' and claimtype <> 'ompf' and boxsource='ro' ))
and bestcopy = 'true'
and imageid in (
'CSRA_210913102Q001140479',
'CSRA_210913101Q001107083',
'CSRA_210913104Q001156745',
'CSRA_210913102Q001119110')

select * from customerCheckIn where rmn = '301VB0329210499A'

111112222

select * from customercheckin where boxorigin = 'fcs' and claimtype <> 'ompf'

select * from customerCheckIn where rmn = '301VB0329210499A'

select * from document where pbatch = '02210901206601'

select *
from document d
where imageid = 'CSRA_210913102Q001140340'
--2021-04-01 22:41:38.053

select ImageID, d.RMN, dcsID, c.trackingno
from document d
left join customerCheckIn c
on d.RMN = c.RMN
where imageid = 'CSRA_210913102Q001140340'
--2021-04-01 18:39:08.010

--update document
--set bestcopy = 'FALSE'
--where imageid = 'CSRA_210743108Q001002377'
select * from document where imageid = 'CSRA_210743108Q001002377'
update document
set ftpstime = '2021-04-01 18:39:08.010'
where imageid = 'CSRA_210743108Q001002377'

update document
set ftpstime = '2021-04-01 20:13:07.693'
where imageid = 'CSRA_210913101Q001107083'

--CSRA_210913102Q001140380


select * from document where imageid = 'CSRA_210913102Q001140479'

select distinct d.imageid + '|' + d.pbatch + '|' + d.dcsid + '|' + d.FileNumber + '|' 
                                + RIGHT('00'+ISNULL(dd.DocID,''),5) + '|' + c.firstname + '|' + c.MiddleInitial + '|' 
                                + c.Lastname + '|' + d.received_date + '|' + CONVERT(varchar(10), d.numpages) + '|'
                                + '04/03/2021 10:19:15 AM' 
                                + '|' + '04/03/2021 10:19:15 AM' 
                                + '|' + d.PBatch + '\' +  d.imageid + '.pdf' + '|' +
								CASE
									When cc.claimtype = 'C' Then 'C' + '|' + '|' + '|' + d.RMN + '|' 
									When cc.claimtype <> 'C' Then 'P' + '|' + '|' + '|' + d.RMN + '|' 
                                    When cc.claimtype is null Then 'C' + '|' + '|' + '|' + d.RMN + '|'
									End claimtype
								from document d
                                left join docid.dbo.docid dd
                                on d.docidDoctype = dd.doctype
                                left join CustomerDATA c
                                on d.dcsid = c.dcsid
								left join customerCheckIn cc
								on d.rmn = cc.RMN
                                where d.ImageID = 'CSRA_210913102Q001140480' and d.pbatch = '02210901206601'



select * from document where imageid in (
'CSRA_210913101Q001107083',
'CSRA_210913102Q001119110',
'CSRA_210913102Q001140479',
'CSRA_210913104Q001156745')

select * from document where imageid in (
'CSRA_210913101Q001107083',
'CSRA_210913102Q001119110',
'CSRA_210913102Q001140479',
'CSRA_210913104Q001156745')

--KMUJJE0R-NWZ7ZJ
select * from document where dcsid = 'KMUJJE0R-NWZ7ZJ'

select ImageID, ftpstime from document where imageid in (
'CSRA_210913101Q001107083',
'CSRA_210913102Q001119110',
'CSRA_210913102Q001140479',
'CSRA_210913104Q001156745')

--ImageID	ftpstime
--CSRA_210913101Q001107083	2021-04-01 20:13:07.693
--CSRA_210913102Q001119110	2021-04-01 21:23:54.000
--CSRA_210913102Q001140479	2021-04-01 22:43:54.820
--CSRA_210913104Q001156745	2021-04-02 00:17:10.487

update document
set ftpstime = '2021-04-02 00:17:10.487'
where imageid = 'CSRA_210913104Q001156745'

--update document
--set bestcopy = 'FALSE'
--where ImageID in (
--'CSRA_210913102Q001119110',
--'CSRA_210913102Q001140479',
--'CSRA_210913104Q001156745')



update document
set ftpstime = null
where ImageID in (
'CSRA_210913101Q001107083',
'CSRA_210913102Q001119110',
'CSRA_210913102Q001140479',
'CSRA_210913104Q001156745')


--update document
--set MA18doctype = 'UPDATEDOCUMENT001', OrgID = 'PDFONLY'
--where imageid = 'CSRA_210913102Q001140479'

select * from document where imageid = 'CSRA_210913102Q001140479'
select * from document where imageid = 'CSRA_210913102Q001140480'
select * from document where imageid = 'CSRA_210913104Q001156745'

update document
set MA18doctype = null, OrgID = 'UPDATETOTALPDFS'
where imageid = 'CSRA_210913102Q001140480'

--CSRA_210913102Q001140480
--2021-04-01 22:43:55.913


--update document
--set ftpstime = '2021-04-01 22:43:55.913'
--where imageid = 'CSRA_210913102Q001140480'