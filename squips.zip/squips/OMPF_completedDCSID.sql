--AllDCSIDs
select distinct p.RMN, p.Pbatch, p.dcsid
--into xoAllDCSIDs
from PbatchDCSMapping p
where exists (select * from customerCheckIn where p.RMN = RMN
and claimtype = 'OMPF')

--DCSIDsUploaded
select distinct d.RMN, d.Pbatch, d.dcsid,
CONVERT(nvarchar, max(d.ftpstime), 101) UploadDateTime
--into xoDCSIDsUploaded
from document d
where exists (select * from customerCheckIn where d.RMN = RMN
and claimtype = 'OMPF')
and exists (select * from document where d.dcsID = dcsid
and d.PBatch = pbatch and ftpstime is not null)
and d.ImageDateTime > '2020-06-01'
group by d.RMN, d.Pbatch, d.dcsid

select * from xoDCSIDsUploaded

select * from xoAllDCSIDs


select distinct x.dcsid,
count(distinct x.pbatch) batchescheckin,
count(distinct v.pbatch) batchesuploaded
--into temp_OMPF_DCSIDs
from xoAllDCSIDs x
left join xoDCSIDsUploaded v
on x.dcsid = v.dcsid
group by x.dcsid


select * from temp_OMPF_DCSIDs

select * from PbatchDCSMapping where dcsid = 'KB6HVGTC-DHZM1Y'

select * from Document where dcsid = 'KB6HVGTC-DHZM1Y'