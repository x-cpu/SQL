DROP TABLE xdocMstr
DROP TABLE xpBtchMstr
DROP TABLE xchckNMstr

--select distinct d.RMN, d.PBatch,
--d.dcsID,
--d.imageid,
--d.numpages,
--d.ftpstime
----into xdocMstr
--from document d
--where d.PBatch like '02%'
--and d.ImageDateTime >= '2021-01-01'

select distinct T.RMN, T.PBatch,
T.dcsID, T.ImageID, T.NumPages, 
T.ftpstime
into xdocMstr
FROM
(select distinct d.RMN, d.PBatch,
d.dcsID,
d.imageid,
d.numpages,
d.ftpstime
from document d
where d.PBatch like '02%'
and d.ImageDateTime >= '2021-01-01') T
where exists (select * from stats where T.PBatch = kbatch)


select distinct p.RMN, p.Pbatch, p.dcsid
into xpBtchMstr
from PbatchDCSMapping p
where p.invtime >= '2020-01-01'

select distinct c.RMN, c.trackingno, c.claimtype
into xchckNMstr
from customerCheckIn c
where c.insertdate >= '2020-01-01'
and RMN <> ''


--average
--COMPLETED RMN
select AVG(Y.Images) AverageImages
FROM
(select distinct X.RMN, X.Images
FROM
(select distinct T.RMN, T.Images, T.NumBatchA,
count (distinct p.pbatch) NumBatchB
FROM
(select distinct d.RMN, sum(d.numpages) Images,
count(distinct d.pbatch) NumBatchA
from xdocMstr d
where d.PBatch like '02%'
group by d.RMN) T
left join xpBtchMstr p
on T.RMN = p.RMN
where exists (select * from xdocMstr where T.RMN = RMN and ftpstime is not null)
group by T.RMN, T.Images, T.NumBatchA) X
left join xchckNMstr c
on X.RMN = c.RMN
where X.NumBatchA = X.NumBatchB
and c.claimtype <> 'OMPF') Y