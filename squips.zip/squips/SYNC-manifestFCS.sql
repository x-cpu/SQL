--select * from manifestDCS

--begin 376 and ends with E

select * from manifestDCSfcs
select distinct pbatch from fcs
select * from manifestdcs where dcsid = 'KSFYLZT9KM93FH'
select * from boxFCS


select * from manifestDCS 
where RMN like '376%' 
and RMN like '%e'
and insertdate >= '2021-08-17'