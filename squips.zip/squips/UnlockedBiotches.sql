select u.UserName, w.WSName Workstation,
a.ConnectStatus, a.BatchID, b.BatchName,
a.TimeStamp, a.Operation, a.EventCode, a.EventComment 
from Audit a
left join Users u
on a.UserID = u.UserID
left join Workstations w
on a.WSID = w.WSID
left join Batches b
on a.BatchID = b.BatchID
where a.EventComment = 'Unlock Batch'
and a.TimeStamp >= CAST(GETDATE() as Date)
and a.BatchID = '10139691'
order by a.TimeStamp