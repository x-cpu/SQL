select distinct
RMN,
dcsID,
ImageID,
CONVERT(varchar, ImageDateTime, 23) 'PDF Created',
NumPages 'Image Count Per PDF'
from document
where CONVERT(varchar, ftpstime, 23) = CONVERT(varchar, GETDATE(), 23)

select distinct
RMN,
dcsID,
ImageID,
ImageDateTime,
--CONVERT(varchar, ImageDateTime, 23) 'PDF Created',
NumPages 'Image Count Per PDF'
from document
where ftpstime >= CONVERT(varchar, GETDATE(), 23)

--base
select distinct
RMN,
dcsID,
ImageID,
ImageDateTime,
NumPages 'Image Count Per PDF'
from document 
where ftpstime >= CONVERT(varchar, GETDATE(), 23)

--with join
select distinct
d.RMN,
d.dcsID,
d.ImageID,
d.ImageDateTime,
d.NumPages 'Image Count Per PDF',
c.Recvdate 'Date of Receipt',
cc.claimtype
from document d
left join CustomerDATA c
on d.dcsID = c.dcsID and d.Pbatch = c.Pbatch
left join customerCheckIn cc
on d.RMN = cc.RMN
where d.ftpstime >= CONVERT(varchar, GETDATE(), 23)

--with join MORE
select distinct
d.RMN,
d.dcsID,
d.ImageID,
d.ImageDateTime 'PDF Created',
d.NumPages 'Image Count Per PDF',
c.Firstname, c.Lastname,
d.FileNumber, d.docidDoctype DocType,
c.Recvdate 'Date of Receipt',
cc.claimtype
from document d
left join CustomerDATA c
on d.dcsID = c.dcsID and d.Pbatch = c.Pbatch
left join customerCheckIn cc
on d.RMN = cc.RMN
where d.ftpstime >= CONVERT(varchar, GETDATE(), 23)


--with join but f'n better

select distinct T.RMN,
T.dcsID,
T.ImageID,
CONVERT(varchar, T.ImageDateTime, 23) 'PDF Created',
T.[Image Count Per PDF],
FROM
(select distinct 
d.RMN,
d.dcsID,
d.ImageID,
d.ImageDateTime,
d.NumPages 'Image Count Per PDF',
c.Recvdate 'Date of Receipt'
from document d
left join CustomerDATA c
on d.dcsID = c.dcsID and d.Pbatch = c.Pbatch
where d.ftpstime >= CONVERT(varchar, GETDATE(), 23)) T
left join customerCheckIn cc
on T.RMN = cc.RMN