select distinct x.imageid, d.pbatch, 'x.iDRSBatch' = null, x.NumPages, 'x.FLN' = null,
d.FileNumber, d.RMN, x.docidDocType, d.received_date, 
'Status' = null, 'OrgID' = null, 'TrackingNumber' = null, 'ShipmentDate' = null,
'UniqueID_Livonia' = null, 'CarrierType' = null, d.ImageDateTime,
'ftpstime' = null, 'PrepID'='', 'RecordNumber'=null, 'SysKey'='', 'newimageid' = null,
'ENFandPrint_Error'=null, 'ENFandPrint_Path'=null, 'MA18doctype'=null, 'comments'=null,
'dcc'=null, d.JulianDate, d.XrayBarcode,'bestcopy'=null, d.dcsID
from document_OMPF_part12x x
left join document d
on substring(x.imageid, 0, 25) = d.imageid
where len(x.imageid) > 24
--and x.insertdate > '2021-05-06'
and x.docidDocType is not null
and not exists (select * from document where x.imageid = imageid)


select * from tempDocument2021p04 where imageid = 'CSRA_210133108Q02106256801'
