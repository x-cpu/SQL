select x.RMN, x.TrackingNo, x.Batches,
count(distinct p.DCSID) [DCSIDs],
x.InProgress, x.Exported, x.Uploaded
--into [xOMPF Summary_special2]
from [xOMPF Summary] x
left join PbatchDCSMapping p
on x.RMN = p.RMN
group by x.RMN, x.TrackingNo, x.Batches,
x.InProgress, x.Exported, x.Uploaded



select * from xOutstandingBatches_special
select * from [xOMPF Summary_special2]