select * from xscancomplete_20210813


select distinct d.ImageID, PBatch, T.dcsID, d.newimageid
FROM
(select distinct dcsid, max(ftpstime) UploadDateTime from document where dcsid in (
select distinct dcsID from xMissingDCS20211029_match
where status = 'matching')
and filesize <> 0
and len(newimageid) < 2
group by dcsid) T
left join document d
on T.UploadDateTime = d.ftpstime
and T.dcsID = d.dcsID
order by pbatch desc

select distinct d.ImageID, PBatch, T.dcsID,
d.ftpstime, d.orgid, d.MA18doctype,
CASE
	WHEN d.newimageid is null or d.newimageid = '' Then d.ImageID
	ELSE d.newimageid
	END newimageid
	--into xscancomplete20210805x
	--into xscancomplete_20210813bck
FROM
(select distinct dcsid, max(ftpstime) UploadDateTime from document where dcsid in (
select distinct dcsid from xscancomplete_20210813)
and filesize <> 0
--and len(newimageid) < 2
--and PBatch like '01%'
group by dcsid) T
left join document d
on T.UploadDateTime = d.ftpstime
and T.dcsID = d.dcsID
where d.FileSize <> 0
order by dcsid, imageid

select * from document where dcsid in (
'KI7PX3JIOXIIB0')