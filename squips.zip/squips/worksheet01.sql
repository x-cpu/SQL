use dva	
select * from document where dcsid = 'LJ73N8SI-4I5TF4'
select * from PbatchDCSMapping where dcsid = 'LE8O5R90-NLKFP4'
select * from CustomerDATA where dcsid = 'LE8O5R90-NLKFP4'
select * from manifestDCS where dcsid = 'LE8O5R90-NLKFP4'


select * from customerCheckIn
where rmn = '376VB0622236663E'

select * from customerCheckIn
where rmn = '376VB0217236663E'

select max(syskey) from customerCheckIn


update document 
set FileNumber = '294184650', dcsid = 'LJ73N8SI-4I5TF4',
RMN = '376VB0622236663E'
where dcsid = 'LE8O5R90-NLKFP4'
and pbatch = '02230601402623'
and imageid in (
'CSRA_230673104Q001005472')

update PbatchDCSMapping 
set dcsid = 'LJ73N8SI-4I5TF4',
RMN = '376VB0622236663E'
where dcsid = 'LE8O5R90-NLKFP4'

update CustomerDATA 
set FileNumber = '294184650', dcsid = 'LJ73N8SI-4I5TF4',
Firstname = 'JOHN', MiddleInitial = 'D', Lastname = 'MCDERMOTT',
RMN = '376VB0622236663E', participantID = ''
where dcsid = 'LE8O5R90-NLKFP4'
and pbatch = '02230601402623'

update manifestDCS 
set dcsid = 'LJ73N8SI-4I5TF4',
RMN = '376VB0622236663E'
where dcsid = 'LE8O5R90-NLKFP4'


select distinct d.imageid + '|' + d.pbatch + '|' + d.dcsid + '|' + d.FileNumber + '|' 
+ RIGHT('00'+ISNULL(dd.DocID,''),5) + '|' + c.firstname + '|' + c.MiddleInitial + '|' 
+ c.Lastname + '|' + d.received_date + '|' + CONVERT(varchar(10), d.numpages) + '|'
+ '06/28/2023 9:19:15 AM' 
+ '|' + '06/28/2023 9:19:15 AM' 
+ '|' + d.PBatch + '\' +  d.imageid + '.pdf' + '|' +
	CASE
		When cc.claimtype = 'C' Then 'C' + '|' + '|' + '|' + d.RMN + '|' 
		When cc.claimtype <> 'C' Then 'P' + '|' + '|' + '|' + d.RMN + '|' 
		End claimtype
from document d
left join docid.dbo.docid dd
on d.docidDoctype = dd.doctype
left join CustomerDATA c
on d.dcsid = c.dcsid
left join customerCheckIn cc
on d.rmn = cc.RMN
where d.ImageID = 'CSRA_230673104Q001005472' and d.pbatch = '02230601402623'


update document
set ftpstime = null, Comments = null, MA18doctype = 'UPDATEDOCUMENT001', OrgID = 'PDFONLY'
where ImageID in (
'CSRA_231573103Q001006833')