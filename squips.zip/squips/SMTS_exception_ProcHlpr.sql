select * from document where dcsid = 'L5SBASEK-7EMHEW'
select * from customerdata where dcsid = 'KVI9OP36MU5UU5'
select * from PbatchDCSMapping where pbatch = '02213081075103'

--select * into dvarp.dbo.document_KVI9OP36MU5UU5 
--from document where dcsid = 'KVI9OP36MU5UU5'

--select * into dvarp.dbo.customerData_KVI9OP36MU5UU5 
--from customerData where dcsid = 'KVI9OP36MU5UU5'


--update PbatchDCSMapping
--set dcsid = 'L5SBASEK-7EMHEW'
--where dcsid = 'KVI9OP36MU5UU5'
--and pbatch = '02213081075103'

--update document 
--set dcsid = 'L5SBASEK-7EMHEW'
--where dcsid = 'KVI9OP36MU5UU5'
--and pbatch = '02213081075103'

--update CustomerDATA 
--set dcsid = 'L5SBASEK-7EMHEW'
--where dcsid = 'KVI9OP36MU5UU5'
--and pbatch = '02213081075103'

select * from customerdata where dcsid = 'L5SBASEK-7EMHEW'

--update CustomerDATA
--set Lastname = 'MORGAN', 
--Firstname = 'SUSAN', 
--MiddleInitial = 'T'
--where dcsid = 'L5SBASEK-7EMHEW'

select * from document where imageid = 'CSRA_213093105Q001009382'


