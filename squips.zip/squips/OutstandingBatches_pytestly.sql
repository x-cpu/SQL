select distinct d.RMN, d.Pbatch, d.dcsid, d.ImageID,
CONVERT(nvarchar, max(d.ftpstime), 101) UploadDateTime
into xoDCSIDsUploaded2
from document d
where exists (select * from customerCheckIn where d.RMN = RMN
and claimtype = 'OMPF')
and exists (select * from document where d.dcsID = dcsid
and d.PBatch = pbatch and ftpstime is not null)
and d.ImageDateTime > '2020-06-01'
group by d.RMN, d.Pbatch, d.dcsid, d.ImageID


select distinct T.RMN, T.TrackingNO,
T.xBatches, T.DCSIDs, T.ExportedBatches,

FROM
(select distinct M.RMN, M.TrackingNo,
count(distinct M.BatchName) Batches,
count(distinct M.DCSID) DCSIDs,
count(distinct M.ExportedBatchName) ExportedBatches,
count(distinct u.pbatch) UploadedBatches,
count(distinct u.dcsid) UploadedDCSIDs
from xompf1 M
left join xoDCSIDsUploaded2 u
on M.BatchName = u.PBatch
group by M.RMN, M.TrackingNo) T


select distinct X.RMN, X.TrackingNo,
X.Batches, X.DCSIDs,
X.Batches - X.ExportedBatches,
X.ExportedBatches, X.UploadedBatches,
X.UploadedDCSIDs
FROM
(select distinct T.RMN, T.TrackingNo,
count(distinct T.BatchName) Batches,
count(distinct T.DCSID) DCSIDs,
count(distinct T.ExportedBatchName) ExportedBatches,
count(distinct T.UploadedBatch) UploadedBatches,
count(distinct T.UploadedDCSID) UploadedDCSIDs
FROM
(select distinct M.RMN, M.TrackingNo,
M.BatchName, M.DCSID, M.ExportedBatchName, 
u.pbatch UploadedBatch, u.dcsid UploadedDCSID
from xompf1 M
left join xoDCSIDsUploaded2 u
on M.BatchName = u.PBatch) T
group by T.RMN, T.TrackingNo) X


select distinct BatchName, WFStep, BatchLocation, BatchStatus, TotalImages 
into xompf2 
from [mtv-va-sql-4\p1].turboscanng1.dbo.batches b
left join PhysicalBatch p
on b.BatchName = p.PBatch
where exists (select * from customerCheckIn where p.RMN = RMN
and claimtype = 'OMPF')


select distinct BatchName
into xompf3
from [mtv-va-sql-2\p923].IBMLTEST_Data.dbo.batchtable


	--WHEN T.BatchStatus = 'Exported' Then 'Exported [' + (T.TotalDocs - T.TotalUploaded) + ' of ' + T.TotalDocs + ' docs(s) pending upload]'
	--WHEN T.BatchStatus = 'Pending OpenBox Import' and i.BatchName is null Then 'Pending IBML Scan'
	--Else T.BatchStatus
	--END BatchStatus

select distinct T.RMN, T.TrackingNo, T.BatchName,
T.OpenBoxBatchLocation,
CASE
	When T.BatchStatus = 'Exported' Then 'Pending Upload'
	When T.BatchStatus = 'Pending OpenBox Import' and i.BatchName is null Then 'Pending IBML Scan'
	Else T.BatchStatus
	END BatchStatus, T.TotalImages, T.SpecialMediaoPaper, T.DCSIDPaper, T.DCSIDSM
FROM
(select X.RMN, X.TrackingNo, X.BatchName,
X.OpenBoxBatchLocation, X.BatchStatus,
X.TotalImages, X.SpecialMediaoPaper, X.DCSIDPaper, X.DCSIDSM,
count(distinct u.imageID) TotalDocs,
count(distinct u.UploadDateTime) TotalUploaded
FROM
(select distinct M.RMN, M.TrackingNo,
M.BatchName,
CASE
	WHEN b.WFStep = 1 Then 'Capture'
	WHEN b.WFStep = 2 Then 'Enhance1'
	WHEN b.WFStep = 3 Then 'FOCR'
	WHEN b.WFStep = 4 Then 'Enhance2'
	WHEN b.WFStep = 5 Then 'Separation'
	WHEN b.WFStep = 6 Then 'ImageQC'
	WHEN b.WFStep = 7 Then 'AutoIndex'
	WHEN b.WFStep = 8 Then 'DocID'
	WHEN b.WFStep = 9 Then 'DocIDQC'
	WHEN b.WFStep = 10 Then 'Manual Index'
	WHEN b.WFStep = 11 Then 'Manual IndexQC'
	WHEN b.WFStep = 12 and batchlocation = 64 then 'Verification'
	WHEN b.WFStep = 13 and batchlocation <> 0 then 'Export'  
	END OpenBoxBatchLocation,
CASE
	WHEN M.ExportedBatchName is not null then 'Exported'
	WHEN BatchStatus = 1 Then 'Ready'
	WHEN BatchStatus = 2 Then 'In Process'
	WHEN BatchStatus = 4 Then 'Suspended'
	WHEN BatchStatus = 8 Then 'Auto-Fail'
	WHEN M.ExportedBatchName is null and b.BatchName is null then 'Pending OpenBox Import'	
	END BatchStatus, b.TotalImages,
CASE
	WHEN M.BatchClassName = 'SM' Then 'SM'
	ELSE 'P'
	END SpecialMediaoPaper,
CASE
	WHEN M.BatchClassName <> 'SM' Then count(distinct M.dcsid)
	ELSE 0
	END DCSIDPaper,
CASE 
	WHEN M.BatchClassName = 'SM' Then count(distinct M.dcsid)
	ELSE 0
	END DCSIDSM
from xompf1 M
left join xompf2 b
on M.BatchName = b.BatchName
group by M.RMN, M.TrackingNo, M.BatchName, b.WFStep, b.BatchLocation,
M.ExportedBatchName, b.BatchStatus, b.BatchName, b.TotalImages, M.BatchClassName) X
left join xoDCSIDsExported u
on X.BatchName = u.pbatch
where u.UploadDateTime is null
group by X.RMN, X.TrackingNo, X.BatchName, X.OpenBoxBatchLocation, X.BatchStatus, X.TotalImages,
X.SpecialMediaoPaper, X.DCSIDPaper, X.DCSIDSM) T
left join xompf3 i
on T.Batchname = i.BatchName
order by T.BatchName



--select * from xompf1
--select * from xoDCSIDsUploaded2
--select * from xompf3