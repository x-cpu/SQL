select distinct x.dcsid DCSID,
	STUFF((select '; ' + z.BatchName
		FROM xPendingOMPF20220418 z
		where z.dcsid = x.dcsid
		for XML PATH('')), 1, 1, '') [Batches Pending Export]
from xPendingOMPF20220418 x
group by x.dcsid, x.BatchName
order by 1


select * from xPendingOMPF20220418


select * from dcsid_p1_recon_20220902


select distinct x.dcsid DCSID, x.CheckInStatus,
	STUFF((select '; ' + z.BatchName
		FROM dcsid_p1_recon_20220902 z
		where z.dcsid = x.dcsid
		for XML PATH('')), 1, 1, '') [BatchName(s)]
		into dcsid_p2_recon_20220902
from dcsid_p1_recon_20220902 x
group by x.dcsid, x.CheckInStatus, x.BatchName
order by x.CheckInStatus
