USE [DVA]
GO

/****** Object:  Table [dbo].[Document]    Script Date: 3/28/2021 10:02:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Document](
	[ImageID] [nvarchar](50) NULL,
	[PBatch] [nvarchar](50) NULL,
	[iDRSBatch] [nvarchar](50) NULL,
	[NumPages] [int] NULL,
	[FLN] [nvarchar](50) NULL,
	[FileNumber] [nvarchar](50) NULL,
	[RMN] [nvarchar](50) NULL,
	[docidDoctype] [nvarchar](255) NULL,
	[received_date] [nvarchar](50) NULL,
	[Status] [nvarchar](255) NULL,
	[OrgID] [nvarchar](50) NULL,
	[TrackingNumber] [nvarchar](50) NULL,
	[ShipmentDate] [datetime] NULL,
	[UniqueID_Livonia] [nvarchar](50) NULL,
	[CarrierType] [nvarchar](50) NULL,
	[ImageDateTime] [datetime] NULL,
	[ftpstime] [datetime] NULL,
	[PrepID] [nvarchar](50) NULL,
	[RecordNumber] [bigint] NULL,
	[SysKey] [bigint] IDENTITY(1,1) NOT NULL,
	[newimageid] [nvarchar](50) NULL,
	[ENFandPrint_Error] [nvarchar](255) NULL,
	[ENFandPrint_Path] [nvarchar](255) NULL,
	[MA18doctype] [nvarchar](50) NULL,
	[Comments] [nvarchar](255) NULL,
	[DCC] [nvarchar](3) NULL,
	[JulianDate] [nvarchar](5) NULL,
	[XrayBarcode] [nvarchar](50) NULL,
	[bestcopy] [nvarchar](50) NULL,
	[dcsID] [nvarchar](50) NULL,
	[FileSize] [bigint] NULL,
	[UploadProcessTime] [int] NULL,
	[PDFTrigger] [nvarchar](25) NULL,
	[UploadTrigger] [nvarchar](25) NULL,
	[PDFMachine] [nvarchar](50) NULL,
	[UploadMachine] [nvarchar](50) NULL,
	[CharCount] [int] NULL,
	[Form526Data] [nvarchar](750) NULL,
	[LOCSUpdate] [int] NULL,
	[OCRExportTime] [datetime] NULL,
	[isMachinePrint] [int] NULL,
	[isHandPrint] [int] NULL,
	[DCSIDComplete] [bit] NULL,
 CONSTRAINT [PK_Document] PRIMARY KEY CLUSTERED 
(
	[SysKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 100) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Document] ADD  CONSTRAINT [DF_Document_ImageDateTime]  DEFAULT (getdate()) FOR [ImageDateTime]
GO

ALTER TABLE [dbo].[Document] ADD  CONSTRAINT [DF_Document_LOCSUpdate]  DEFAULT ((0)) FOR [LOCSUpdate]
GO

ALTER TABLE [dbo].[Document] ADD  CONSTRAINT [DF_Document_isMachinePrint]  DEFAULT ((0)) FOR [isMachinePrint]
GO

ALTER TABLE [dbo].[Document] ADD  CONSTRAINT [DF_Document_isHandPrint]  DEFAULT ((0)) FOR [isHandPrint]
GO

ALTER TABLE [dbo].[Document] ADD  CONSTRAINT [DF_Document_DCSIDComplete]  DEFAULT ((0)) FOR [DCSIDComplete]
GO


