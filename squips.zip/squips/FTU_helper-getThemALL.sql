select * from xfcsftu_20210920

select distinct d.dcsid, d.FileNumber,
x.newfilenumber, d.pbatch, d.imageid,
d.OrgID, d.MA18doctype, d.ftpstime
from xfcsftu_20210920 x
left join document d
on x.imageid = d.ImageID


--HERE WE GO
--HERE WE GO
--HERE WE GO
--HERE WE GO
--HERE WE GO
--HERE WE GO
--HERE WE GO
--HERE WE GO
select distinct d.dcsid, d.FileNumber,
T.NewFilenumber, d.pbatch, d.imageid,
d.OrgID, d.MA18doctype, d.ftpstime
into xfcsftu_20210920_bck_ftpstime
FROM
(select distinct d.dcsid, d.FileNumber,
x.newfilenumber NewFilenumber, d.pbatch, d.imageid,
d.OrgID, d.MA18doctype, d.ftpstime
from xfcsftu_20210920 x
left join document d
on x.imageid = d.ImageID) T
left join document d
on T.FileNumber = d.FileNumber
and T.dcsID = d.dcsID

select distinct d.imageid, d.pbatch, d.dcsid, d.OrgID, d.MA18doctype, d.ftpstime
FROM
(select distinct d.dcsid, d.FileNumber,
x.newfilenumber NewFilenumber, d.pbatch, d.imageid,
d.OrgID, d.MA18doctype, d.ftpstime
from xfcsftu_20210920 x
left join document d
on x.imageid = d.ImageID) T
left join document d
on T.FileNumber = d.FileNumber
and T.dcsID = d.dcsID
order by pbatch, ImageID



--	CSRA_211623108Q001016818