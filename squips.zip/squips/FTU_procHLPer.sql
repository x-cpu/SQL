select * from document where dcsid = 'KYCZXZ4Q8K276J'
select * from PbatchDCSMapping where dcsid = 'KYCZXZ4Q8K276J'
select * from customerCheckIn where rmn = '376VB0718197441D'
select * from document where rmn = '376VB0718197441D'
select * from document where imageid = 'CSRA_211673106Q001025067'

select * 
into dvarp.dbo.[document_01203651204908_bck]
from document where pbatch = '01203651204908'

select * 
into dvarp.dbo.[document_xDCSIDS20220425_matchingxx01_bck]
from document where dcsid in (select distinct dcsID from xDCSIDS20220425xxx)
--CSRA_221043105P001010752

select * 
into dvarp.dbo.[document_CSRA_221043105P001010752_bck]
from document where imageid = 'CSRA_221043105P001010752'

select distinct dcsid, filenumber, 
FileNumber newfilenumber,
pbatch, imageid
from document 
where imageid in (select distinct imageid from xsc02_dcsids_20220425x)

select * from xsc02_dcsids_20220425x


select distinct imageid, pbatch
from document 
where imageid in 
(select distinct imageid from xsc02_dcsids_20220425x)
order by ImageID



select dcsid, * from document
where imageid in (select distinct imageid from xDCSIDS20220425xxx)
and dcsid = 'KFMQXPH28HILCT'

select * from document where dcsid = 'KQM6KHBQA4E2EK'
select * from dvarp.dbo.document_RMC_SC20220412_bck where imageid = 'CSRA_211443106Q001008414'

--update d
--set d.ftpstime = x.ftpstime
--from document d
--left join dvarp.dbo.document_RMC_SC20220412_bck x
--on d.ImageID = x.imageid
--where d.ImageID = x.imageid	

select distinct d.dcsid
from document d
where exists (select * from dvarp.dbo.document_RMC_SC20220412_bck 
where d.dcsid = d.dcsid and pbatch like '02%')


--select * 
--into dvarp.dbo.[document_RMC_SC20220412_bck]
--from document d
--where ImageID in (select distinct ImageID from ximageIDs20220412)

update document
set OrgID = 'DCSSCANNINGCOMPLETE'
where imageid in (
select distinct ImageID from ximageIDs20220412)

--DCSSCANNINGCOMPLETE