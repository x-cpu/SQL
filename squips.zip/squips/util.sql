select distinct DATEPART(hour, ftpstime) Hr, 
sum(numpages) TotalImages
from document
where ftpstime >= '2023-06-05'
group by DATEPART(hour, ftpstime)
order by Hr

select * from FTPError where imageid = 'CSRA_230153104Q001000009'
select * from FTPError where insertdate >= '2023-04-01'
select * from document where ftpstime >= '2023-04-28'

update document
set FileNumber  = '14283166'
where dcsid = 'LGQOONSYFLDQAZ'

update CustomerDATA
set FileNumber  = '14283166'
where dcsid = 'LGQOONSYFLDQAZ'

update CustomerDATA
set Lastname  = 'HOUTZ'
where dcsid = 'L091AKRQ43ZLMM'

update CustomerDATA
set Firstname  = 'JOSEPH'
where dcsid = 'LGFVUD9A-EJXYCE'

update document
set DCSIDComplete = 0
where imageid = 'CSRA_230943103Q001000466'


update document
set NumPages = 12
where imageid = 'CSRA_230683105Q001004721'

select * from document where dcsid = 'LDXEP2GCINED2B'
and ftpstime is null


use dva	
select * from document where dcsid = 'LGPK3CS3-GFCU1'
select * from PbatchDCSMapping where dcsid = 'LGPK3CS3-GFCU1'
select * from CustomerDATA where dcsid = 'LGQOONSYFLDQAZ'
select * from manifestDCS where dcsid = 'LGXZGMCC5BXFT5'
select * from customerCheckIn where RMN = '376VB0502239199E'
select * from customerCheckIn where RMN = '376VB0418239199E'
select * from manifestDCS where RMN = '376VB0302233016E'
select * from PhysicalBatch where RMN = '376VB0503223016E'
--delete from manifestDCS where dcsid = 'L6NKOIBA68DJAA'
select * from document where imageid ='CSRA_230963106Q001004391'
                                                                                                                                                                                                                                          
update customerdata
set Lastname = 'BROCKMAN'
where dcsid = 'LG58IPL16LESAE'
and syskey = 13772535

update CustomerDATA
set Firstname = 'WILLIAM'
where  dcsid = 'L63G0ABG-GNPAKN'

select max(syskey) from CustomerDATA

--02230651103624
--02230671802104
--02230871609301


select * from document where pbatch = '02231421715901'
select * from stats where kbatch = '02231421715901'
--select * from stats_ibml where kbatch = '02230531001907'

--update document
--set rmn = '376VB0502239199E', FileNumber = '380544577', 
--dcsID = 'LH6AVIBA-3477IB', pbatch = '02231151397319'
--where imageid in (
--'CSRA_231183105Q001001800',
--'CSRA_231183105Q001001801',
--'CSRA_231183105Q001001802')

select * from CustomerDATA where pbatch = '02231151307319'



select * from TURBOSCANNG_OCR1.dbo.batches where batchname = '02230611402604'
select * from TURBOSCANNG_OCR2.dbo.batches where batchname = '02230611402604'
select * from TURBOSCANNG_OCR3.dbo.batches where batchname = '02230611402604'
select * from TURBOSCANNG_OCR4.dbo.batches where batchname = '02230611402604'
select * from TURBOSCANNG_OCR5.dbo.batches where batchname = '02230611402604'

--update TURBOSCANNG_OCR5.dbo.batches
--set Priority = 1
--where batchname = '02230611402604'


select distinct d.imageid + '|' + d.pbatch + '|' + d.dcsid + '|' + d.FileNumber + '|' 
+ RIGHT('00'+ISNULL(dd.DocID,''),5) + '|' + c.firstname + '|' + c.MiddleInitial + '|' 
+ c.Lastname + '|' + d.received_date + '|' + CONVERT(varchar(10), d.numpages) + '|'
+ '06/08/2023 9:19:15 AM' 
+ '|' + '06/08/2023 9:19:15 AM' 
+ '|' + d.PBatch + '\' +  d.imageid + '.pdf' + '|' +
	CASE
		When cc.claimtype = 'C' Then 'C' + '|' + '|' + '|' + d.RMN + '|' 
		When cc.claimtype <> 'C' Then 'P' + '|' + '|' + '|' + d.RMN + '|' 
		End claimtype
from document d
left join docid.dbo.docid dd
on d.docidDoctype = dd.doctype
left join CustomerDATA c
on d.dcsid = c.dcsid
left join customerCheckIn cc
on d.rmn = cc.RMN
where d.ImageID = 'CSRA_231573103Q001006833' and d.pbatch = '02231311100503'

update document
set ftpstime = null, Comments = null, MA18doctype = 'UPDATEDOCUMENT001', OrgID = 'PDFONLY'
where ImageID in (
'CSRA_231573103Q001006833')



select dcsid, * 
from document
where dcsid in (
'LH0Q7H3M-45Z8GH',
'LGQO3IMN-Q0KHQT',
'LGUT6HKH-AC3EXR',
'LGUU8JFOV8NLY0',
'LGUX5NBI-66Q25D',
'LH4T8AIM-IAPW3I',
'LH50W1GX2YB6A7',
'LH0FAM9G-X7XGUQ',
'LGUV1S4KU3ZSAS')
 and ftpstime is null


select distinct dcsid, max(ftpstime) uploaddatetime 
from document
where dcsid in (

group by dcsid


select * from Stats_IBML where kbatch = '02231381907110'
select * from Stats_IBML where kbatch = '02231381907111'
select * from PhysicalBatch where pbatch = '02231381907111'

