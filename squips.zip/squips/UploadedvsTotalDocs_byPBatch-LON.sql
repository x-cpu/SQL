select distinct PBatch BatchName, RMN, 
--DCSID, 
count(distinct imageid) Docs,
count(distinct CONVERT(varchar, ftpstime,1) + imageid) UploadDocs,
--, PBatch BatchName,
'Batch uploaded successfully on ' + CONVERT(varchar, max(ftpstime), 1) [IT Comments]
--LastUploadDateTime 
from [lon-va-sql-1\p1,2001].[dva].[dbo].document where pbatch in (
'02231095108501',
'02231095108502',
'02231095108503',
'02231095108504',
'02231095108505',
'02231095108506',
'02231095108507',
'02231095108508',
'02231095108509',
'02231095108510',
'02231095108511',
'02231095108512')
group by pbatch, rmn
--, dcsid
order by pbatch