select * from xmissinguuids
select * from vtguuids

select distinct 
m.EffectiveReceivedDate, 
m.PacketID, v.UUID, s.ackTime, v.uploadDate
from xMissingUUIDs m
left join smsDCSMapping s
on m.packetID = s.veteranID
left join CustomerDATA c
on s.dcsid = c.dcsID
left join vvFTPDetails v
on c.FileNumber = v.fileNumber 
and c.Firstname = v.veteranFirstName
and c.Lastname = v.veteranLastName
--and SUBSTRING(s.batchname, 9,1) = '5'
and s.ackTime is not null
and not exists (select * from vtguuids2 where v.uuid = [column 0])
--and exists (select * from DCSID_UUID_mapping where v.uuid = uuid)
and v.uuid not like 'x_%'
order by m.packetid

--3405
select * from DCSID_UUID_mapping

select * from vvFTPDetails where uuid in (
'080fa347-702a-48ec-99d7-772f1eb9371e',
'5702fe13-08d6-42aa-95b2-b426c90b4490',
'a4c9e3e6-9b20-44ee-b31d-ff28688edefd')


PacketID	UUID
3710807	04498baf-db4e-4594-bdd1-c475dfb5ebe4
3710807	b37f9014-08a7-464b-892c-395aaddd4a0a

select * from vvFTPDetails where uuid in (
'b37f9014-08a7-464b-892c-395aaddd4a0a',
'04498baf-db4e-4594-bdd1-c475dfb5ebe4')


select * from smsDCSMapping where veteranID in (
'10475489',
'10475490')
