select distinct T.BatchName, 
T.DCSID, T.RMN, T.BatchName1,
m.pbatch BatchName2
FROM
(select distinct b.BatchName,
LTRIM(RIGHT(batchdesc, charindex(':', reverse(batchdesc))-1)) DCSID,
p.RMN RMN,
p.pbatch BatchName1
from batches b
left join [mtv-va-sql-1\p922].dva.dbo.pbatchdcsmapping p
on b.BatchName = p.pbatch
where b.batchname = '02220871204255') T
left join  [mtv-va-sql-1\p922].dva.dbo.manifestdcs m
on T.DCSID = m.dcsid
where T.DCSID = m.dcsid


--small things get bigger
select distinct T.BatchName, 
T.DCSID, T.RMN, T.BatchName1,
m.pbatch BatchName2
FROM
(select distinct b.BatchName,
LTRIM(RIGHT(batchdesc, charindex(':', reverse(batchdesc))-1)) DCSID,
p.RMN RMN,
p.pbatch BatchName1
from batches b
left join [mtv-va-sql-1\p922].dva.dbo.pbatchdcsmapping p
on b.BatchName = p.pbatch
where exists (select distinct batchname from [mtv-va-sql-1\p922].dva.dbo.xbatches20220523
where b.batchname = BatchName)
and b.BatchDesc like '% - Invalid RMN & DCSID combination! RMN: %') T
left join  [mtv-va-sql-1\p922].dva.dbo.manifestdcs m
on T.DCSID = m.dcsid
where T.DCSID = m.dcsid
order by T.BatchName