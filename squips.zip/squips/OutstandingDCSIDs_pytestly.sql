select distinct T.RMN, T.TrackingNo, T.BatchName, T.DCSID,
T.OpenBoxBatchLocation,
CASE
	When T.BatchStatus = 'Exported' Then 'Pending Upload'
	When T.BatchStatus = 'Pending OpenBox Import' and i.BatchName is null Then 'Pending IBML Scan'
	Else T.BatchStatus
	END BatchStatus, T.TotalImages, T.SpecialMediaoPaper
FROM
(select X.RMN, X.TrackingNo, X.BatchName, X.dcsid DCSID,
X.OpenBoxBatchLocation, X.BatchStatus,
X.TotalImages, X.SpecialMediaoPaper,
count(distinct u.imageID) TotalDocs,
count(distinct u.UploadDateTime) TotalUploaded
FROM
(select distinct M.RMN, M.TrackingNo,
M.BatchName, M.DCSID,
CASE
	WHEN b.WFStep = 1 Then 'Capture'
	WHEN b.WFStep = 2 Then 'Enhance1'
	WHEN b.WFStep = 3 Then 'FOCR'
	WHEN b.WFStep = 4 Then 'Enhance2'
	WHEN b.WFStep = 5 Then 'Separation'
	WHEN b.WFStep = 6 Then 'ImageQC'
	WHEN b.WFStep = 7 Then 'AutoIndex'
	WHEN b.WFStep = 8 Then 'DocID'
	WHEN b.WFStep = 9 Then 'DocIDQC'
	WHEN b.WFStep = 10 Then 'Manual Index'
	WHEN b.WFStep = 11 Then 'Manual IndexQC'
	WHEN b.WFStep = 12 and batchlocation = 64 then 'Verification'
	WHEN b.WFStep = 13 and batchlocation <> 0 then 'Export'  
	END OpenBoxBatchLocation,
CASE
	WHEN M.ExportedBatchName is not null then 'Exported'
	WHEN BatchStatus = 1 Then 'Ready'
	WHEN BatchStatus = 2 Then 'In Process'
	WHEN BatchStatus = 4 Then 'Suspended'
	WHEN BatchStatus = 8 Then 'Auto-Fail'
	WHEN M.ExportedBatchName is null and b.BatchName is null then 'Pending OpenBox Import'	
	END BatchStatus, b.TotalImages,
CASE
	WHEN M.BatchClassName = 'SM' Then 'SM'
	ELSE 'P'
	END SpecialMediaoPaper
from xompf1 M
left join xompf2 b
on M.BatchName = b.BatchName
group by M.RMN, M.TrackingNo, M.BatchName, M.DCSID, b.WFStep, b.BatchLocation,
M.ExportedBatchName, b.BatchStatus, b.BatchName, b.TotalImages, M.BatchClassName) X
left join xoDCSIDsExported u
on X.BatchName = u.pbatch
where u.UploadDateTime is null
group by X.RMN, X.TrackingNo, X.BatchName, X.DCSID, X.OpenBoxBatchLocation, X.BatchStatus, X.TotalImages,
X.SpecialMediaoPaper) T
left join xompf3 i
on T.Batchname = i.BatchName
order by T.BatchName


--select * from PbatchDCSMapping where Pbatch = '02210401800112'