--summary
select distinct X.Month, X.StatusCode, count(distinct X.dcsid) #dcsIDs,
count(distinct X.imageid) #Docs, sum(X.Images) Images
FROM
(select distinct T.dcsID, T.ImageID, T.NumPages Images, MONTH(T.ImageDateTime) Month,
CASE
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber'
	WHEN T.Comments like 'Status Code: 422 - Response Error: Unable to find image with Id:  %' Then 'Status Code: 422 - Response Error: Unable to find image with Id'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.%' Then 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.'
	WHEN T.Comments like 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 400 - Response Error: Amazon SQS Client Exception%' Then 'Status Code: 400 - Response Error: Amazon SQS Client Exception'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS%' Then 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS File Number and/or DCSID not found%' Then 'Status Code: 426 - Response Error: FCS File Number and/or DCSID not found'
	WHEN T.Comments like 'Status Code: 426 - Response Error: RO File Number and/or DCSID not found%' Then 'Status Code: 426 - Response Error: RO File Number and/or DCSID not found'
	WHEN T.Comments like 'Status Code: 426 - Response Error: RO RMN/BoxNumber not found%' Then 'Status Code: 426 - Response Error: RO RMN/BoxNumber not found'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid veteranFirstName%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid veteranFirstName'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid veteranLastName%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid veteranLastName'
	--Status Code: 426 - Response Error: FCS File Number and/or DCSID not found [CSRA_230533103Q001001152]
	--Status Code: 426 - Response Error: RO File Number and/or DCSID not found [CSRA_230583104Q001002663]
	--Status Code: 426 - Response Error: RO RMN/BoxNumber not found [CSRA_222423108Q001009171]
	--Status Code: 412 - Response Error: Metadata required field error: Invalid veteranFirstName (09633492) [CSRA_231103102Q001002112]
	--Status Code: 412 - Response Error: Metadata required field error: Invalid veteranLastName (THOMPS1N) [CSRA_230603106Q001006107]
	WHEN T.Comments like 'Status Code: 412 - Response Error: totalPDFs (%) is less than total number of received PDFs%' Then 'Status Code: 412 - Response Error: totalPDFs (*) is less than total number of received PDFs (*) for DCS' 
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS%' Then 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS.'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (%) is equal to system totalPDFs%' Then 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (*) is equal to system totalPDFs (*) for DCS (*).'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found %' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0' Then 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch%' Then 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS %' Then 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Maximum File Size Exceeded%' Then 'Status Code: 412 - Response Error: Maximum File Size Exceeded'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Found%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Found'
	ELSE SUBSTRING(T.Comments, 0, 40) 
	END StatusCode
FROM
(select *
from document 
where Comments like 'Status Code: 4%'
and ImageDateTime >= '2021-01-01'
and ftpstime is null) T) X
group by X.Month, X.StatusCode
order by X.Month, X.StatusCode, #dcsIDs, #Docs

--detailed
select distinct T.DCSID, T.ImageID, T.NumPages,
T.ImageDateTime,
CASE
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber'
	WHEN T.Comments like 'Status Code: 422 - Response Error: Unable to find image with Id:  %' Then 'Status Code: 422 - Response Error: Unable to find image with Id'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.%' Then 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.'
	WHEN T.Comments like 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 400 - Response Error: Amazon SQS Client Exception%' Then 'Status Code: 400 - Response Error: Amazon SQS Client Exception'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS%' Then 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS File Number and/or DCSID not found%' Then 'Status Code: 426 - Response Error: FCS File Number and/or DCSID not found'
	WHEN T.Comments like 'Status Code: 426 - Response Error: RO File Number and/or DCSID not found%' Then 'Status Code: 426 - Response Error: RO File Number and/or DCSID not found'
	WHEN T.Comments like 'Status Code: 426 - Response Error: RO RMN/BoxNumber not found%' Then 'Status Code: 426 - Response Error: RO RMN/BoxNumber not found'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid veteranFirstName%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid veteranFirstName'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid veteranLastName%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid veteranLastName'
	--Status Code: 426 - Response Error: FCS File Number and/or DCSID not found [CSRA_230533103Q001001152]
	--Status Code: 426 - Response Error: RO File Number and/or DCSID not found [CSRA_230583104Q001002663]
	--Status Code: 426 - Response Error: RO RMN/BoxNumber not found [CSRA_222423108Q001009171]
	--Status Code: 412 - Response Error: Metadata required field error: Invalid veteranFirstName (09633492) [CSRA_231103102Q001002112]
	--Status Code: 412 - Response Error: Metadata required field error: Invalid veteranLastName (THOMPS1N) [CSRA_230603106Q001006107]
	WHEN T.Comments like 'Status Code: 412 - Response Error: totalPDFs (%) is less than total number of received PDFs%' Then 'Status Code: 412 - Response Error: totalPDFs (*) is less than total number of received PDFs (*) for DCS' 
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS%' Then 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS.'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (%) is equal to system totalPDFs%' Then 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (*) is equal to system totalPDFs (*) for DCS (*).'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found %' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0' Then 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch%' Then 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS %' Then 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Maximum File Size Exceeded%' Then 'Status Code: 412 - Response Error: Maximum File Size Exceeded'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Found%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Found'
	ELSE SUBSTRING(T.Comments, 0, 40) 
	END COMMENTS
FROM
(select *
from document 
where Comments like 'Status Code: 4%'
and ImageDateTime >= '2021-01-01'
and ftpstime is null) T
order by  ImageDateTime, dcsid, COMMENTS



--summary by dcsid and pbatch
select distinct X.Year, X.Month, X.StatusCode,
X.BatchName, X.dcsid,
count(distinct X.imageid) #Docs, sum(X.Images) Images
FROM
(select distinct T.PBatch BatchName, T.dcsID, T.ImageID, T.NumPages Images, YEAR(T.ImageDateTime) Year,
MONTH(T.ImageDateTime) Month,
CASE
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber'
	WHEN T.Comments like 'Status Code: 422 - Response Error: Unable to find image with Id:  %' Then 'Status Code: 422 - Response Error: Unable to find image with Id'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.%' Then 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.'
	WHEN T.Comments like 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 400 - Response Error: Amazon SQS Client Exception%' Then 'Status Code: 400 - Response Error: Amazon SQS Client Exception'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS%' Then 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS File Number and/or DCSID not found%' Then 'Status Code: 426 - Response Error: FCS File Number and/or DCSID not found'
	WHEN T.Comments like 'Status Code: 426 - Response Error: RO File Number and/or DCSID not found%' Then 'Status Code: 426 - Response Error: RO File Number and/or DCSID not found'
	WHEN T.Comments like 'Status Code: 426 - Response Error: RO RMN/BoxNumber not found%' Then 'Status Code: 426 - Response Error: RO RMN/BoxNumber not found'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid veteranFirstName%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid veteranFirstName'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid veteranLastName%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid veteranLastName'
	--Status Code: 426 - Response Error: FCS File Number and/or DCSID not found [CSRA_230533103Q001001152]
	--Status Code: 426 - Response Error: RO File Number and/or DCSID not found [CSRA_230583104Q001002663]
	--Status Code: 426 - Response Error: RO RMN/BoxNumber not found [CSRA_222423108Q001009171]
	--Status Code: 412 - Response Error: Metadata required field error: Invalid veteranFirstName (09633492) [CSRA_231103102Q001002112]
	--Status Code: 412 - Response Error: Metadata required field error: Invalid veteranLastName (THOMPS1N) [CSRA_230603106Q001006107]
	WHEN T.Comments like 'Status Code: 412 - Response Error: totalPDFs (%) is less than total number of received PDFs%' Then 'Status Code: 412 - Response Error: totalPDFs (*) is less than total number of received PDFs (*) for DCS' 
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS%' Then 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS.'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (%) is equal to system totalPDFs%' Then 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (*) is equal to system totalPDFs (*) for DCS (*).'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found %' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0' Then 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch%' Then 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS %' Then 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Maximum File Size Exceeded%' Then 'Status Code: 412 - Response Error: Maximum File Size Exceeded'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Found%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Found'
	ELSE SUBSTRING(T.Comments, 0, 40) 
	END StatusCode
FROM
(select *
from document 
where Comments like 'Status Code: 4%'
and ImageDateTime >= '2021-01-01'
and ftpstime is null) T) X
group by X.Year, X.Month, X.StatusCode, X.BatchName, X.dcsid
order by X.Year, X.Month, X.StatusCode, #Docs
