select * from PhysicalBatch
where invtime >= '2023-04-26'
--OMPFCorr

select * from PhysicalBatch 
where pbatch like '022315918032%'

update PhysicalBatch
set cordest = 'OMPFCorr'
where pbatch like '022315918032%'
