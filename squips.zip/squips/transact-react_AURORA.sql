select * from Transaction202304x

select distinct CONVERT(date, transactiondate, 101) DateGranted,
Device, Person, Credential, count(distinct TransactionDate) #Entries
from Transaction202304x
where Person <> 'Lunnie Smith'
group by CONVERT(date, transactiondate, 101), Device, Person, Credential
order by DateGranted

select * from Transaction202303xxx

--summary
select distinct CONVERT(date, transactiondate, 101) DateGranted,
Device, Person, Credential, count(distinct TransactionDate) #Entries
from Transaction20230609
--where (Person <> 'Lunnie Smith' or Person <> 'Rick Schepmoes')
where CONVERT(date, transactiondate, 101) >= '2023-06-08'
and CONVERT(date, transactiondate, 101) < '2023-06-09'
and person not in (
'Lunnie Smith',
'Rick Schepmoes')
group by CONVERT(date, transactiondate, 101), Device, Person, Credential
order by DateGranted


--detailed
select distinct transactiondate DateTimeGranted,
Device, Person, Credential, count(distinct TransactionDate) #Entries
from Transaction20230609
--where (Person <> 'Lunnie Smith' or Person <> 'Rick Schepmoes')
where CONVERT(date, transactiondate, 101) >= '2023-06-08'
and CONVERT(date, transactiondate, 101) < '2023-06-09'
and person not in (
'Lunnie Smith',
'Rick Schepmoes')
group by transactiondate, Device, Person, Credential
order by DateTimeGranted