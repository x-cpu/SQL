select distinct imageid, pbatch, filenumber, dcsid, docidDoctype, 
imagedatetime, ftpstime, OrgID, MA18doctype from document
where imageid in (
'CSRA_201193103P001084854',
'CSRA_202383103P001025599',
'CSRA_202443108P001004771',
'CSRA_203433102P001012147',
'CSRA_203513105P001049194',
'CSRA_203663106P001129280',
'CSRA_210253103P001009217',
'CSRA_210283101P001056924',
'CSRA_210333102P001018714',
'CSRA_210533105P001112897',
'CSRA_210623104P001143798',
'CSRA_210713102P001005620')


select distinct imageid, pbatch, filenumber, dcsid, docidDoctype, 
imagedatetime, ftpstime, OrgID, MA18doctype from document
where dcsid in (
'KC3LJ0ZGKN88OG',
'KBAS4LD9NG4R2G',
'KD08V2WV-4Y9DCV')
order by dcsid


--CSRA_202723102P001006398