--part 1 for detail view
select distinct x.syskey, Z.RMN,
Z.TotalBatches, Z.TotalBatchesExported,
Z.Status01, Z.pUploadBatches, Z.pImageIDs, Z.fTimes,
CASE
	WHEN Z.pImageIDs = Z.fTimes Then 'AllUploaded'
	END Status02
FROM 
(select Y.RMN, 
Y.TotalBatches, 
Y.TotalBatchesExported,
Y.Status01,
Y.pUploadBatches,
count(distinct d.imageid) pImageIDs,
count(distinct d.ftpstime) fTimes
FROM
(select distinct X.RMN, X.TotalBatches, X.TotalBatchesExported,
CASE
	WHEN X.TotalBatches = X.TotalBatchesExported Then 'AllExported'
	END Status01,
	count(distinct d.PBatch) pUploadBatches
FROM
(select distinct x.RMN RMN, count(distinct p.pbatch) TotalBatches, 
count(distinct s.kbatch) TotalBatchesExported
from xrmns20211116x x
left join PbatchDCSMapping p
on x.RMN = p.RMN
left join stats s
on x.RMN = s.RMN
group by x.RMN) X
left join document d
on X.RMN = d.RMN
group by X.RMN, X.TotalBatches, X.TotalBatchesExported) Y
left join document d
on Y.RMN = d.RMN
group by Y.RMN, 
Y.TotalBatches, 
Y.TotalBatchesExported,
Y.Status01,
Y.pUploadBatches) Z
left join xrmns20211116x x
on Z.RMN = x.RMN


--part 2 for summary view

select distinct T.syskey,
CASE
	WHEN T.TotalBatches = T.pUploadBatches and Status02 = 'AllUploaded'
	THEN 'All Batches (' + CONVERT(varchar(10),T.TotalBatches) + ') for RMN ' + T.RMN + ' have uploaded successfully.'
	WHEN T.TotalBatches <> T.TotalBatchesExported
	THEN CONVERT(varchar(10), (T.TotalBatches - T.TotalBatchesExported)) + ' batch(es) pending 1st Job Export'
	ELSE null
	END x1
FROM
(select distinct x.syskey syskey, Z.RMN,
Z.TotalBatches, Z.TotalBatchesExported,
Z.Status01, Z.pUploadBatches, Z.pImageIDs, Z.fTimes,
CASE
	WHEN Z.pImageIDs = Z.fTimes Then 'AllUploaded'
	END Status02
FROM 
(select Y.RMN, 
Y.TotalBatches, 
Y.TotalBatchesExported,
Y.Status01,
Y.pUploadBatches,
count(distinct d.imageid) pImageIDs,
count(distinct d.ftpstime) fTimes
FROM
(select distinct X.RMN, X.TotalBatches, X.TotalBatchesExported,
CASE
	WHEN X.TotalBatches = X.TotalBatchesExported Then 'AllExported'
	END Status01,
	count(distinct d.PBatch) pUploadBatches
FROM
(select distinct x.RMN RMN, count(distinct p.pbatch) TotalBatches, 
count(distinct s.kbatch) TotalBatchesExported
from xrmns20211116x x
left join PbatchDCSMapping p
on x.RMN = p.RMN
left join stats s
on x.RMN = s.RMN
group by x.RMN) X
left join document d
on X.RMN = d.RMN
group by X.RMN, X.TotalBatches, X.TotalBatchesExported) Y
left join document d
on Y.RMN = d.RMN
group by Y.RMN, 
Y.TotalBatches, 
Y.TotalBatchesExported,
Y.Status01,
Y.pUploadBatches) Z
left join xrmns20211116x x
on Z.RMN = x.RMN) T
order by T.syskey