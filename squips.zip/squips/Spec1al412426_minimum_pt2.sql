
select distinct X.Year, X.Month, X.StatusCode, count(distinct X.dcsid) #dcsIDs,
count(distinct X.imageid) #Docs, sum(X.Images) #Images
FROM
(select distinct T.dcsID, T.ImageID, 
sum(T.numpages) Images, 
YEAR(T.ImageDateTime) Year, MONTH(T.ImageDateTime) Month,
CASE
	WHEN T.Comments like 'Status Code: 412%' Then 'Status Code: 412'
	WHEN T.Comments like 'Status Code: 426%' Then 'Status Code: 426'
	ELSE SUBSTRING(T.Comments, 0, 40) 
	END StatusCode
FROM
(select *
from document 
where Comments like 'Status Code: 4%'
and ImageDateTime >= '2021-01-01'
and ftpstime is null) T
group by T.dcsID, T.ImageID, T.ImageDateTime, T.Comments) X
group by X.Year, X.Month, X.StatusCode
order by X.Year, X.Month, X.StatusCode, #dcsIDs, #Docs, #Images
