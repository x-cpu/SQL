select sum(numpages) from [lon-va-sql-1\p1,2001].dva.dbo.document
where ftpstime >= '2022-09-15'
and ftpstime < '2022-09-16'

select * 
from [lon-va-sql-1\p1,2001].dva.dbo.xrecon20220916

select distinct pbatch, 
sum(numpages),
max(s.releasedate) 
--into xrecon20220916
from document d 
left join stats s
on d.pbatch = s.kbatch
where ftpstime >= '2022-09-15'
and ftpstime < '2022-09-16'
group by d.PBatch

select sum(numpages) 
from [lon-va-sql-1\p1,2001].dva.dbo.document
where ftpstime >= '2022-09-15'
and ftpstime < '2022-09-16'

select distinct a.batchname,
max(a.TimeStamp) DocIDDateTime
into xrecon20220916docid
from [lon-va-sql-4\p4].turboscanng1.dbo.ts_audit a
where exists (select * from xrecon20220916 where a.batchname = batchname)
and a.TSModule = 'DocID'
group by a.batchname

select distinct a.batchname,
max(a.TimeStamp) AutoIndexDateTime
into xrecon20220916autoindex
from [lon-va-sql-4\p4].turboscanng1.dbo.ts_audit a
where exists (select * from xrecon20220916 where a.batchname = batchname)
and a.TSModule = 'AutoIndex'
group by a.batchname



select distinct x.batchname,
x.Images,
a.DocIDDateTime AutoIndexDateTime,
d.DocIDDateTime,
x.ExportDateTime
from xrecon20220916 x
left join xrecon20220916docid d
on x.batchname = d.batchname
left join xrecon20220916autoindex a
on x.batchname = a.batchname



select distinct x.batchname,
x.numpages,
a.DocIDDateTime AutoIndexDateTime,
d.DocIDDateTime,
x.ExportDateTime
from xrecon x
left join xrecondocid d
on x.batchname = d.batchname
left join xreconai a
on x.batchname = a.batchname