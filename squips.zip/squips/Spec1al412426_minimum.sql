
select distinct X.Year, X.Month, X.StatusCode, count(distinct X.dcsid) #dcsIDs,
count(distinct X.imageid) #Docs 
FROM
(select distinct T.dcsID, T.ImageID, YEAR(T.ImageDateTime) Year, MONTH(T.ImageDateTime) Month,
CASE
	WHEN T.Comments like 'Status Code: 412%' Then 'Status Code: 412'
	WHEN T.Comments like 'Status Code: 426%' Then 'Status Code: 426'
	ELSE SUBSTRING(T.Comments, 0, 40) 
	END StatusCode
FROM
(select *
from document 
where Comments like 'Status Code: 4%'
and ImageDateTime >= '2021-01-01'
and ftpstime is null) T) X
group by X.Year, X.Month, X.StatusCode
order by X.Year, X.Month, X.StatusCode, #dcsIDs, #Docs
