
--part1
select distinct X.RMN, X.BatchName,
X.[CheckIn DateTime], 
X.[Prep End DateTime],
X.[QA1 End DateTime], X.[QA2 End DateTime]
FROM 
(select distinct p.RMN, T.BatchName, 
p.invtime [CheckIn DateTime],
CASE 
	WHEN T.TSModule = 'Capture' Then T.TimeStamp
	END [Prep End DateTime],
CASE 
	WHEN T.TSModule = 'ImageQC' Then T.TimeStamp
	END [QA1 End DateTime],
CASE 
	WHEN T.TSModule = 'DocID' Then T.TimeStamp
	END [QA2 End DateTime]
FROM
(select distinct BatchName,
CASE
	WHEN TSModule = '4' Then 'Enhance'
	WHEN TSModule = '1' Then 'Capture'
	ELSE TSModule 
	END TSModule,
max(TimeStamp) TimeStamp, UserProcTime
into xstats20210304
from TS_Audit t
where TimeStamp >= '2021-01-01'
and TimeStamp < '2021-03-01'
and UserProcTime is not null
and UserImagesProcessed > 0
and exists (select * from [mtv-va-sql-1\p922].dva.dbo.stats s where t.BatchName = s.kbatch)
group by BatchName, TSModule, TimeStamp, UserProcTime) T
left join [mtv-va-sql-1\p922].dva.dbo.physicalbatch p
on T.BatchName = p.pbatch) X
where [Prep End DateTime] is not null
and [QA1 End DateTime] is not null	
and [QA2 End DateTime] is not null


--trimmer
select distinct T.RMN, T.BatchName,
max(T.[CheckIn DateTime]) [CheckIn DateTime], 
max(T.[Prep End DateTime]) [Prep End DateTime],
max(T.[QA1 End DateTime]) [QA1 End DateTime], 
max(T.[QA2 End DateTime]) [QA2 End DateTime]
FROM
(select distinct p.RMN, x.BatchName, 
p.invtime [CheckIn DateTime],
CASE 
	WHEN x.TSModule = 'Capture' Then max(x.TimeStamp)
	END [Prep End DateTime],
CASE 
	WHEN x.TSModule = 'ImageQC' Then max(x.TimeStamp)
	END [QA1 End DateTime],
CASE 
	WHEN x.TSModule = 'DocID' Then max(x.TimeStamp)
	END [QA2 End DateTime]
from xstats20210304 x
left join [mtv-va-sql-1\p922].dva.dbo.physicalbatch p
on x.BatchName = p.pbatch
group by p.RMN, x.BatchName, p.invtime, x.TSModule) T
where T.BatchName = '01210051201501'
group by T.RMN, T.BatchName


select distinct T.BatchName, T.TSModule,
max(T.timestamp2) sTimeStamp, max(T.eTimeStamp) eTimeStamp
FROM
(select distinct batchname,
tsmodule, timestamp eTimeStamp,
DATEADD(SECOND, - userproctime, timestamp) timestamp2
from xstats20210304
where batchname = '02210301839001') T
group by T.batchname, T.tsmodule

--part 2
--finale work reposit
select distinct T.BatchName, T.TSModule,
max(T.timestamp2) sTimeStamp, max(T.eTimeStamp) eTimeStamp
into xstats20210304x
FROM
(select distinct batchname,
tsmodule, timestamp eTimeStamp,
DATEADD(SECOND, - userproctime, timestamp) timestamp2
from xstats20210304) T
group by T.batchname, T.tsmodule

select * from xstats20210304x

--part 3
select distinct T.RMN, T.BatchName,
max(T.[CheckIn DateTime]) [CheckIn DateTime], 
max(T.[Prep Start DateTime]) [Prep Start DateTime],
max(T.[Prep End DateTime]) [Prep End DateTime],
max(T.[QA1 Start DateTime]) [QA1 Start DateTime], 
max(T.[QA1 End DateTime]) [QA1 End DateTime], 
max(T.[QA2 Start DateTime]) [QA2 Start DateTime],
max(T.[QA2 End DateTime]) [QA2 End DateTime]
FROM
(select distinct p.RMN, x.BatchName, 
p.invtime [CheckIn DateTime],
CASE 
	WHEN x.TSModule = 'Capture' Then max(x.sTimeStamp)
	END [Prep Start DateTime],
CASE 
	WHEN x.TSModule = 'Capture' Then max(x.eTimeStamp)
	END [Prep End DateTime],
CASE 
	WHEN x.TSModule = 'ImageQC' Then max(x.sTimeStamp)
	END [QA1 Start DateTime],
CASE 
	WHEN x.TSModule = 'ImageQC' Then max(x.eTimeStamp)
	END [QA1 End DateTime],
CASE 
	WHEN x.TSModule = 'DocID' Then max(x.sTimeStamp)
	END [QA2 Start DateTime],
CASE 
	WHEN x.TSModule = 'DocID' Then max(x.eTimeStamp)
	END [QA2 End DateTime]
from xstats20210304x x
left join [mtv-va-sql-1\p922].dva.dbo.physicalbatch p
on x.BatchName = p.pbatch
group by p.RMN, x.BatchName, p.invtime, x.TSModule) T
--where T.BatchName = '01210051201501'
group by T.RMN, T.BatchName



--part 3 or part 4
select distinct T.RMN, T.BatchName,
max(T.[CheckIn DateTime]) [CheckIn DateTime], 
max(T.[Prep Start DateTime]) [Prep Start DateTime],
max(T.[Prep End DateTime]) [Prep End DateTime],
max(T.[QA1 Start DateTime]) [QA1 Start DateTime], 
max(T.[QA1 End DateTime]) [QA1 End DateTime], 
max(T.[QA2 Start DateTime]) [QA2 Start DateTime],
max(T.[QA2 End DateTime]) [QA2 End DateTime]
into xstats20210304f
FROM
(select distinct p.RMN, x.BatchName, 
p.invtime [CheckIn DateTime],
CASE 
	WHEN x.TSModule = 'Capture' Then max(x.sTimeStamp)
	END [Prep Start DateTime],
CASE 
	WHEN x.TSModule = 'Capture' Then max(x.eTimeStamp)
	END [Prep End DateTime],
CASE 
	WHEN x.TSModule = 'ImageQC' Then max(x.sTimeStamp)
	END [QA1 Start DateTime],
CASE 
	WHEN x.TSModule = 'ImageQC' Then max(x.eTimeStamp)
	END [QA1 End DateTime],
CASE 
	WHEN x.TSModule = 'DocID' Then max(x.sTimeStamp)
	END [QA2 Start DateTime],
CASE 
	WHEN x.TSModule = 'DocID' Then max(x.eTimeStamp)
	END [QA2 End DateTime]
from xstats20210304x x
left join [mtv-va-sql-1\p922].dva.dbo.physicalbatch p
on x.BatchName = p.pbatch
group by p.RMN, x.BatchName, p.invtime, x.TSModule) T
--where T.BatchName = '01210051201501'
group by T.RMN, T.BatchName

select * from xstats20210304f


select x.RMN, x.BatchName, x.[CheckIn DateTime],
x.[Prep Start DateTime], x.[Prep End DateTime], 
x.[QA1 Start DateTime], x.[QA1 End DateTime],
x.[QA2 Start DateTime], x.[QA2 End DateTime], 
max(s.releasedate) [Export DateTime] 
into xstats20210304fx
from xstats20210304f x
left join [mtv-va-sql-1\p922].dva.dbo.stats s
on x.batchname = s.kbatch
where [Prep Start DateTime] is not null
and [Prep End DateTime] is not null
and [QA1 Start DateTime] is not null
and [QA1 End DateTime] is not null
and [QA2 Start DateTime] is not null
and [QA2 End DateTime] is not null
group by x.RMN, x.BatchName, x.[CheckIn DateTime],
x.[Prep Start DateTime], x.[Prep End DateTime], 
x.[QA1 Start DateTime], x.[QA1 End DateTime],
x.[QA2 Start DateTime], x.[QA2 End DateTime]


select * from xstats20210304fx

select distinct x.RMN, x.BatchName,
count(distinct d.imageid) Docs,
sum(d.numpages) Images
from xstats20210304f x
left join TS_Audit t
on x.batchname = t.BatchName 
left join [mtv-va-sql-1\p922].dva.dbo.document d
on x.BatchName = d.pbatch
and x.[QA2 End DateTime] = t.TimeStamp
where t.tsmodule = 'DocID'
group by x.RMN, x.BatchName


select x.*, max(d.ftpstime) UploadDateTime,
CASE
	WHEN p.batchclassname = 'SM' Then 'SpecialMedia'
	ELSE 'Paper'
	END 'Type'
from xstats20210304fx x
left join [mtv-va-sql-1\p922].dva.dbo.document d
on x.BatchName = d.pbatch
left join [mtv-va-sql-1\p922].dva.dbo.physicalbatch p
on x.BatchName = p.pbatch
group by x.RMN, x.BatchName, x.[CheckIn DateTime],
x.[Prep Start DateTime], x.[Prep End DateTime],
x.[QA1 Start DateTime], x.[QA1 End DateTime],
x.[QA2 Start DateTime], x.[QA2 End DateTime],
x.[Export DateTime], p.batchclassname