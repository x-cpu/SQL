select * from xstats20210830fx2 x
where exists (select * from [mtv-va-sql-1\p922].dva.dbo.customerCheckIN
where claimtype = 'OMPF' and x.rmn = rmn)