select distinct 
m.EffectiveReceivedDate, 
m.PacketID, v.UUID, s.ackTime, v.uploadDate
from xMissingUUIDs m
left join smsDCSMapping s
on m.packetID = s.veteranID
left join CustomerDATA c
on s.dcsid = c.dcsID
left join vvFTPDetails v
on c.FileNumber = v.fileNumber 
and c.Firstname = v.veteranFirstName
and c.Lastname = v.veteranLastName
and SUBSTRING(s.batchname, 9,1) = '5'
and s.ackTime is not null
and not exists (select * from vtguuids2 where v.uuid = [column 0])
--and exists (select * from DCSID_UUID_mapping where v.uuid = uuid)
and v.uuid not like 'x_%'
order by m.packetid


(select distinct 
m.EffectiveReceivedDate, 
m.PacketID, s.ackTime
from xMissingUUIDs m
left join smsDCSMapping s
on m.packetID = s.veteranID) T