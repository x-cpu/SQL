select x.*, 
CASE
	WHEN p.BatchClassName = 'SM' Then 'SM'
	WHEN p.BatchClassName = 'OMPF' Then 'P'
	ELSE ''
	END [SpecialMedia/P],
CASE
	WHEN p.BatchClassName = 'OMPF' Then count(distinct pp.dcsid)
	ELSE ''
	END [DCSID-Paper],
CASE
	WHEN p.BatchClassName = 'SM' Then count(distinct pp.dcsid)
	ELSE ''
	END [DCSID-SM]
--into xOutstandingBatches_special
from xOutstandingBatches x
left join PhysicalBatch p
on x.batchname = p.PBatch
left join PbatchDCSMapping pp
on x.batchname = pp.Pbatch
group by x.RMN, x.TrackingNo, x.Batchname,
x.OpenBoxBatchLocation, x.BatchStatus, x.TotalImages,
p.BatchClassName


select * from xOutstandingBatches

select * from PbatchDCSMapping where pbatch in (
'02210341163301',
'02210341163501',
'02210341163701',
'02210341163901',
'02210341164101',
'02210341164301',
'02210341164501')