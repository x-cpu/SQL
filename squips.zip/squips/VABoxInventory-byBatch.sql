select distinct A.CheckInDate, A.RMN, A.PBatch,
count(distinct A.Active) ACTIVE,
count(distinct A.COMPLETED) COMPLETED
FROM
(select distinct Z.CheckInDate, Z.RMN, Z.PBatch,
CASE
	WHEN Z.Total - Z.Uploaded <> 0 Then Z.RMN
	END ACTIVE,
CASE
	WHEN Z.Total - Z.Uploaded = 0 Then Z.RMN
	END COMPLETED
FROM
(select distinct X.CheckInDate, X.RMN, X.PBatch, count(distinct X.pbatch) Total,
count(distinct X.NotUploaded) NotUploaded, 
count(distinct X.Uploaded) Uploaded
FROM
(select distinct T.CheckInDate, T.RMN, p.PBatch,
CASE
	WHEN not exists (select * from document where p.PBatch = pbatch and ftpstime is not null)
	THEN p.PBatch
	END NotUploaded,
CASE
	WHEN exists (select * from document where p.PBatch = pbatch and ftpstime is not null)
	THEN p.PBatch
	END Uploaded
FROM
(select distinct p.RMN, CONVERT(varchar, min(p.InvTime), 101) CheckInDate 
from PhysicalBatch p with (NOLOCK)
where exists (select * from customerCheckIn 
where claimtype = 'OMPF' 
and insertdate >= '2021-06-10' and p.RMN = RMN)
and p.InvTime >= '2021-06-10'
and p.PBatch like '02%'
and p.PBatch not like '%test%'
group by p.RMN) T
left join PhysicalBatch p
on T.RMN = p.RMN
left join document d
on p.PBatch = d.PBatch) X
group by X.CheckInDate, X.RMN, X.PBatch) Z) A
group by A.CheckInDate, A.RMN, A.PBatch