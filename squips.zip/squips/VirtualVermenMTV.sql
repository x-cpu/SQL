select * from customerCheckIn where rmn = '376VB0425239500E'

select * from manifestDCS where pbatch like '022308911044%'
select * from PhysicalBatch where pbatch like '022308911044%'
select * from PbatchDCSMapping where pbatch like '022308911044%'
select * from stats where kbatch like '022308911044%'

--376VB0330232781E
--376VB0330232781E


update manifestDCS
set rmn = '376VB0330232781E'
where pbatch like '022308911044%'

update PhysicalBatch
set rmn = '376VB0330232781E'
where pbatch like '022308911044%'

update PbatchDCSMapping
set rmn = '376VB0330232781E'
where pbatch like '022308911044%'