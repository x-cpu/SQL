select distinct T.DCSID,
T.ImageDateTime,
CASE
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber'
	WHEN T.Comments like 'Status Code: 422 - Response Error: Unable to find image with Id:  %' Then 'Status Code: 422 - Response Error: Unable to find image with Id'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.%' Then 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.'
	WHEN T.Comments like 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 400 - Response Error: Amazon SQS Client Exception%' Then 'Status Code: 400 - Response Error: Amazon SQS Client Exception'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS%' Then 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 412 - Response Error: totalPDFs (%) is less than total number of received PDFs%' Then 'Status Code: 412 - Response Error: totalPDFs (*) is less than total number of received PDFs (*) for DCS' 
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS%' Then 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS.'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (%) is equal to system totalPDFs%' Then 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (*) is equal to system totalPDFs (*) for DCS (*).'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found %' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0' Then 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch%' Then 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS %' Then 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS'
	ELSE SUBSTRING(T.Comments, 0, 40) 
	END COMMENTS
FROM
(select *
from document 
where Comments like 'Status Code: 4%'
and ImageDateTime >= '2021-01-01'
and ftpstime is null) T
order by ImageDateTime, COMMENTS



select distinct X.StatusCode, count(distinct X.dcsid) #dcsIDs
FROM
(select distinct T.dcsID,
CASE
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber'
	WHEN T.Comments like 'Status Code: 422 - Response Error: Unable to find image with Id:  %' Then 'Status Code: 422 - Response Error: Unable to find image with Id'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.%' Then 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.'
	WHEN T.Comments like 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 400 - Response Error: Amazon SQS Client Exception%' Then 'Status Code: 400 - Response Error: Amazon SQS Client Exception'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS%' Then 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 412 - Response Error: totalPDFs (%) is less than total number of received PDFs%' Then 'Status Code: 412 - Response Error: totalPDFs (*) is less than total number of received PDFs (*) for DCS' 
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS%' Then 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS.'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (%) is equal to system totalPDFs%' Then 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (*) is equal to system totalPDFs (*) for DCS (*).'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found %' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0' Then 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch%' Then 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS %' Then 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS'
	ELSE SUBSTRING(T.Comments, 0, 40) 
	END StatusCode
FROM
(select *
from document 
where Comments like 'Status Code: 4%'
and ImageDateTime >= '2021-01-01'
and ftpstime is null) T) X
group by X.StatusCode
order by X.StatusCode, #dcsIDs


select distinct T.DCSID,
T.ImageDateTime,
CASE
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber'
	WHEN T.Comments like 'Status Code: 422 - Response Error: Unable to find image with Id:  %' Then 'Status Code: 422 - Response Error: Unable to find image with Id'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.%' Then 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.'
	WHEN T.Comments like 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 400 - Response Error: Amazon SQS Client Exception%' Then 'Status Code: 400 - Response Error: Amazon SQS Client Exception'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS%' Then 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 412 - Response Error: totalPDFs (%) is less than total number of received PDFs%' Then 'Status Code: 412 - Response Error: totalPDFs (*) is less than total number of received PDFs (*) for DCS' 
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS%' Then 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS.'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (%) is equal to system totalPDFs%' Then 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (*) is equal to system totalPDFs (*) for DCS (*).'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found %' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0' Then 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch%' Then 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS %' Then 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS'
	ELSE SUBSTRING(T.Comments, 0, 40) 
	END COMMENTS
FROM
(select *
from document 
where Comments like 'Status Code: 4%'
and ImageDateTime >= '2021-01-01'
and ftpstime is null) T
order by COMMENTS



select distinct X.Month, X.StatusCode, count(distinct X.dcsid) #dcsIDs,
count(distinct X.imageid) #Docs 
FROM
(select distinct T.dcsID, T.ImageID, MONTH(T.ImageDateTime) Month,
CASE
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Missing QC'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid boxNumber'
	WHEN T.Comments like 'Status Code: 422 - Response Error: Unable to find image with Id:  %' Then 'Status Code: 422 - Response Error: Unable to find image with Id'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.%' Then 'Status Code: 412 - Response Error: The metadata totalPDFs is less or equal to system totalPDFs.'
	WHEN T.Comments like 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: RO File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 400 - Response Error: Amazon SQS Client Exception%' Then 'Status Code: 400 - Response Error: Amazon SQS Client Exception'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS%' Then 'Status Code: 412 - Response Error: The dcsScanningComplete flag for DCS'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS%' Then 'Status Code: 426 - Response Error: FCS File Number and or DCS do not match SMTS'
	WHEN T.Comments like 'Status Code: 412 - Response Error: totalPDFs (%) is less than total number of received PDFs%' Then 'Status Code: 412 - Response Error: totalPDFs (*) is less than total number of received PDFs (*) for DCS' 
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received%' Then 'Status Code: 412 - Response Error: Metadata required field error: RO Box Not Received'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS%' Then 'Status Code: 412 - Response Error: The totalPDFs and dcsScanningComplete fields are previously set for DCS.'
	WHEN T.Comments like 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (%) is equal to system totalPDFs%' Then 'Status Code: 412 - Response Error: The updateTotalPDF flag is False and the total received PDFs (*) is equal to system totalPDFs (*) for DCS (*).'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found %' Then 'Status Code: 412 - Response Error: Metadata required field error: FCS Box Not Found'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0' Then 'Status Code: 412 - Response Error: Metadata required field error: pageCount=0'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch%' Then 'Status Code: 412 - Response Error: Metadata required field error: Box number and NPRC Rack location/RMN mismatch'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Invalid fileNumber'
	WHEN T.Comments like 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber%' Then 'Status Code: 412 - Response Error: Metadata required field error: Missing boxNumber'
	WHEN T.Comments like 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS %' Then 'Status Code: 426 - Response Error: FCS RMN/BoxNumber not found in SMTS'
	ELSE SUBSTRING(T.Comments, 0, 40) 
	END StatusCode
FROM
(select *
from document 
where Comments like 'Status Code: 4%'
and ImageDateTime >= '2021-01-01'
and ftpstime is null) T) X
group by X.Month, X.StatusCode
order by X.Month, X.StatusCode, #dcsIDs, #Docs

