select Y.dcsID, Y.BadFileNumber,
Y.GoodFileNumber, Y.PBatch, Y.ImageID,
d.ftpstime OrigFTPTime, 'NewFTPTime' = null
into xRMCFTU_20210514
FROM
(select distinct X.dcsID, X.BadFileNumber,
r.[File Number to reupload to] GoodFileNumber, 
X.PBatch,
X.ImageID
FROM
(select distinct d.dcsid, d.FileNumber BadFileNumber,
--x.[File Number to reupload to] GoodFileNumber,
d.pbatch, d.ImageID
--into xRMCFTU_20210507
from document d
where pbatch like '02%'
and exists (select * from xRMCFTU_20210507 
where d.dcsid = dcsid)) X
--and d.FileNumber = FileNumber)
left join xRMCFTU_20210507 r
on X.dcsID = r.DCSID
where r.[File Number to reupload to] is not null) Y
left join document d
on Y.ImageID = d.ImageID

select distinct imageid, pbatch from xRMCFTU_20210514
order by pbatch, ImageID


--981

--select * from document where dcsid = 'KH4QMVM8-BWJ5MF'