select distinct T.RMN, T.dcsID, 
Location = 'Exela',
T.[Days Pending],
CASE
	WHEN (T.#Docs = T.#FTPs) and T.#Docs > 0 and T.SC = 1 Then 'Completed'
	WHEN #exportedBatch < #checkedInBatch Then 'Pending batch to be exported'
	END Status
FROM
--base results
(select distinct B.RMN, B.dcsID, B.[Days Pending],
B.#checkedInBatch,
B.#exportedBatch,
B.#Docs,
B.#FTPs,
sum(B.SC) SC
FROM
(select distinct A.RMN, A.dcsID, A.[Days Pending],
A.#checkedInBatch,
A.#exportedBatch,
A.#Docs,
A.#FTPs,
CASE
	WHEN #Docs = #FTPs and #Docs > 0 and d.DCSIDComplete = 1 THEN 1
	ELSE 0
	END SC
FROM
(select distinct Z.RMN, Z.dcsID, Z.[Days Pending],
Z.#checkedInBatch, Z.#exportedBatch,
CASE
	WHEN Z.#checkedInBatch = Z.#exportedBatch THEN count(distinct d.ImageID)
	ELSE 0
	END #Docs,
CASE
	WHEN Z.#checkedInBatch = Z.#exportedBatch THEN count(distinct d.ftpstime)
	ELSE 0
	END #FTPs
FROM
(select distinct Y.RMN, Y.dcsID,
Y.[Days Pending], 
count(distinct Y.DCSID_checkedInBatch) #checkedInBatch, 
count(distinct Y.DCSID_exportedBatch) #exportedBatch
FROM
(select distinct X.RMN, X.dcsID, X.[Days Pending],
X.DCSID_checkedInBatch, s.kbatch DCSID_exportedBatch
FROM
(select distinct x.RMN RMN, x.dcsid dcsID, x.[Days Pending],
p.pbatch DCSID_checkedInBatch
from ExelaOldestDCSIDs20211202 x
left join dva.dbo.pbatchdcsmapping p
on x.dcsid = p.dcsid and x.RMN = p.RMN) X
left join dva.dbo.Stats s
on X.DCSID_checkedInBatch = s.kbatch) Y
group by Y.RMN, Y.dcsID, Y.[Days Pending]) Z
left join dva.dbo.document d
on Z.dcsid = d.dcsID
group by Z.RMN, Z.dcsID, Z.[Days Pending],
Z.#checkedInBatch, Z.#exportedBatch) A
left join dva.dbo.document d
on A.dcsid = d.dcsID) B
group by B.RMN, B.dcsID, B.[Days Pending],
B.#checkedInBatch,
B.#exportedBatch,
B.#Docs,
B.#FTPs) T



select * from dvarp.dbo.ExelaOldestDCSIDs20211202