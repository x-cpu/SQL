select T.dcsid, T.Pbatch, p.BatchClassName
FROM
(select distinct x.dcsid, p.Pbatch 
from DCSIDcompleted_ompf x
left join PbatchDCSMapping p
on x.dcsid = p.dcsid
where exists (select * from PhysicalBatch 
where (BatchClassName = 'sm' 
--or BatchClassName like 'deprep%'
) 
and p.Pbatch = pbatch)
and not exists (select * from PhysicalBatch 
where (BatchClassName <> 'sm' 
--or BatchClassName not like 'deprep%'
) 
and p.Pbatch = pbatch)) T
left join PhysicalBatch p
on T.Pbatch = p.pbatch

select distinct pbatch from PbatchDCSMapping where dcsid = 'KG0ZWKZC-KYRJ0X'

select * from PhysicalBatch where pbatch in (
'02210561200102',
'02210561621301')


select distinct x.dcsid,
CASE 
	WHEN p.BatchClassName = 'SM' or p.BatchClassName like 'Deprep%' Then 'SpecialMedia'
	Else 'Paper'
	END Type
	into xtemp20210722
from DCSIDcompleted_ompf x
left join PbatchDCSMapping pp
on x.dcsid = pp.dcsid
left join PhysicalBatch p
on pp.Pbatch = p.PBatch
order by x.dcsid



select distinct x.dcsid from xtemp20210722 x
where x.type = 'SpecialMedia'
and not exists (select * from xtemp20210722 where x.dcsid = dcsid and type = 'Paper')

select * from manifestDCS where dcsid = 'KJN5IR2W-E1B4SN'
select * from PbatchDCSMapping where dcsid = 'KJN5IR2W-E1B4SN'
select * from PhysicalBatch where pbatch = '02210761600101'

select * from stats where kbatch = '02210761600101'

select * from PhysicalBatch where pbatch like '022101411008%'