select distinct x.imageid, d.dcsid, d.pbatch,
d.OrgID, d.MA18doctype, d.ftpstime, d.docidDoctype, dd.docid
from xdocid20210721 x
left join document d
on x.imageID = d.ImageID
left join docid.dbo.docid_bck20210529 dd
on d.dociddoctype = dd.doctype
order by d.pbatch, x.imageid

select distinct x.imageid, d.dcsid, d.pbatch,
d.OrgID, d.MA18doctype, d.ftpstime, d.docidDoctype
--, dd.docid
--into xdocid20210721_bck
from xdocid20210721 x
left join document d
on x.imageID = d.ImageID
--left join docid.dbo.docid_bck20210529 dd
--on d.dociddoctype = dd.doctype
order by d.pbatch, x.imageid

select distinct pbatch from PbatchDCSMapping where rmn = '316VB0701214768D'
select distinct pbatch from document where rmn = '316VB0701214768D' and ftpstime is not null
--d.dcsid, d.FileNumber, d.FileNumber, d.PBatch, x.imageid
x.imageid, d.PBatch
--, dd.docid
--into xdocid20210721_bck
from xdocid20210721 x
left join document d
on x.imageID = d.ImageID
--left join docid.dbo.docid_bck20210529 dd
--on d.dociddoctype = dd.doctype
order by d.pbatch, x.imageid

--update document
--set docidDoctype = 'VRE Correspondence'
--where imageid in (
--'CSRA_190563101P001026644',
--'CSRA_190563101P001026647',
--'CSRA_190773103P001016255',
--'CSRA_190773103P001016260',
--'CSRA_190773103P001016294',
--'CSRA_190773103P001016303',
--'CSRA_190773103P001016304',
--'CSRA_190773103P001016336',
--'CSRA_190773103P001016337',
--'CSRA_190773103P001016355',
--'CSRA_190773103P001016356',
--'CSRA_190233105P001044656',
--'CSRA_190803101P001035944',
--'CSRA_190803101P001035945',
--'CSRA_190313105P001050204',
--'CSRA_190313105P001050205',
--'CSRA_190313105P001050206',
--'CSRA_190313105P001050207',
--'CSRA_190313105P001050219',
--'CSRA_190313105P001050280',
--'CSRA_190853103P001071066',
--'CSRA_190853103P001071067')


select * from docid.dbo.docid where docid = '1246'


select * from document where dcsid = 'KH6KHWL7-I7GRZV' and ftpstime is null

update document
set FileNumber = '551069773'
where FileNumber = '26592472'
and dcsID = 'JLGQPQJ6-PP1QO7'

update CustomerDATA
set FileNumber = '551069773'
where FileNumber = '26592472'
and dcsID = 'JLGQPQJ6-PP1QO7'