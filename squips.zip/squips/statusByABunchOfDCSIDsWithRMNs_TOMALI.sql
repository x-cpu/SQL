select distinct T.RMN, T.dcsID, 
--Location = 'Exela',
CASE
	WHEN (T.#Docs = T.#FTPs) and T.#Docs > 0 and T.SC = 1 Then 'Completed'
	WHEN #exportedBatch < #checkedInBatch Then 'Pending ' + CAST(T.#pending AS nvarchar(10)) + ' batch to be exported'
	END Status
--into oldtemp_20211203
FROM
--base results
(select distinct B.RMN, B.dcsID,
B.#checkedInBatch,
B.#exportedBatch,
B.#Docs,
B.#FTPs,
sum(B.SC) SC,
B.#checkedInBatch - B.#exportedBatch #pending
FROM
(select distinct A.RMN, A.dcsID,
A.#checkedInBatch,
A.#exportedBatch,
A.#Docs,
A.#FTPs,
CASE
	WHEN #Docs = #FTPs and #Docs > 0 and d.DCSIDComplete = 1 THEN 1
	ELSE 0
	END SC
FROM
(select distinct Z.RMN, Z.dcsID, 
Z.#checkedInBatch, Z.#exportedBatch,
CASE
	WHEN Z.#checkedInBatch = Z.#exportedBatch THEN count(distinct d.ImageID)
	ELSE 0
	END #Docs,
CASE
	WHEN Z.#checkedInBatch = Z.#exportedBatch THEN count(distinct d.ftpstime)
	ELSE 0
	END #FTPs
FROM
(select distinct Y.RMN, Y.dcsID,
count(distinct Y.DCSID_checkedInBatch) #checkedInBatch, 
count(distinct Y.DCSID_exportedBatch) #exportedBatch
FROM
(select distinct X.RMN, X.dcsID, 
X.DCSID_checkedInBatch, s.kbatch DCSID_exportedBatch
FROM
(select distinct x.RMN RMN, x.dcsid dcsID,
p.pbatch DCSID_checkedInBatch
from xRMNDCSIDS20220823x  x
left join dva.dbo.pbatchdcsmapping p
on x.dcsid = p.dcsid and x.RMN = p.RMN) X
left join dva.dbo.Stats s
on X.DCSID_checkedInBatch = s.kbatch) Y
group by Y.RMN, Y.dcsID) Z
left join dva.dbo.document d
on Z.dcsid = d.dcsID
group by Z.RMN, Z.dcsID,
Z.#checkedInBatch, Z.#exportedBatch) A
left join dva.dbo.document d
on A.dcsid = d.dcsID) B
group by B.RMN, B.dcsID,
B.#checkedInBatch,
B.#exportedBatch,
B.#Docs,
B.#FTPs) T

