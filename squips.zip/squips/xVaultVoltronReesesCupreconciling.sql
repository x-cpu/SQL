select * 
--into dvarp.dbo.xVaultUpdates20220322 
from document d
where exists(select * from xvaultPartials20220321 where d.dcsid = dcsid)
and d.MA18doctype is not null
and d.ftpstime is null


select distinct d.dcsid, max(dd.ftpstime) UploadDateTime 
into dvarp.dbo.xVaultWorker20220322
from document d
left join document dd
on d.dcsID = dd.dcsID
where exists(select * from xvaultPartials20220321 x where d.dcsid = x.dcsid)
and d.MA18doctype is not null
and d.ftpstime is null
group by d.dcsID
order by UploadDateTime

select * from dvarp.dbo.xVaultWorker20220322

--update d
--set d.ftpstime = w.UploadDateTime
--from document d
--left join dvarp.dbo.xVaultWorker20220322 w
--on d.dcsID = w.dcsID
--where exists(select * from xvaultPartials20220321 x where d.dcsid = x.dcsid)
--and d.MA18doctype is not null
--and d.ftpstime is null


select * from xvaultPartials20220321 x

--xVaultSC_20220328