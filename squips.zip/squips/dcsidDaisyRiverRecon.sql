--part1
select distinct x.dcsid,
CASE
	WHEN not exists (select * from manifestDCS where x.dcsid = dcsid)
	Then 'Not CheckIn'
	WHEN exists (select * from pbatchdcsmapping where x.dcsid = dcsid)
	Then 'CheckIn - MTV'
	WHEN exists (select * from manifestDCS where x.dcsid = dcsid)
	Then 'x'
	END CheckInStatus, p.Pbatch BatchName
	into dcsid_p1_recon_20220902_altver
from dvarp.dbo.dcsid_recon_20220902 x
left join pbatchdcsmapping p
on x.dcsid = p.dcsid
order by CheckInStatus


--part2
select distinct x.dcsid DCSID, x.CheckInStatus,
	STUFF((select '; ' + z.BatchName
		FROM dcsid_p1_recon_20220902 z
		where z.dcsid = x.dcsid
		for XML PATH('')), 1, 1, '') [BatchName(s)]
		into dcsid_p2_recon_20220902
from dcsid_p1_recon_20220902 x
group by x.dcsid, x.CheckInStatus, x.BatchName
order by x.CheckInStatus

--select * from PbatchDCSMapping where dcsid = 'J6DNZCN7-X5Z10J'

select * 
into dcsid_p2_recon_20220902LON
from [lon-va-sql-1\p1,2001].dva.dbo.dcsid_p2_recon_20220902


--for check if completed
select distinct dcsid
into xdcsid_20220902mtv
from dcsid_p2_recon_20220902 where CheckInStatus = 'CheckIn - MTV'


select * from dcsid_p2_recon_20220902 
where dcsid = 'L6CLJTSP-E1SN8S'

select * from dcsid_p2_recon_20220902 x
where exists (select * from dcsid_p2_recon_20220902LON
where checkinstatus like 'check%' and x.dcsid = dcsid)


--below not WORKING - not right but fuckit
--after Lon done
----part 3
--select x.* into master_dcsid_recon_20220902x
--FROM
--(
--select * from
--dcsid_p2_recon_20220902
--where not exists (
--select * from dcsid_p2_recon_20220902 x
--where exists (select * from dcsid_p2_recon_20220902LON
--where checkinstatus like 'check%' and x.dcsid = dcsid))
--union
--select * from
--dcsid_p2_recon_20220902LON x
--where not exists (select * from dcsid_p2_recon_20220902
--where CheckInStatus like 'not%' and x.DCSID = dcsid)
--) x


select * from master_dcsid_recon_20220902
