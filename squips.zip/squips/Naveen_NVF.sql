select distinct x.RMN,
x.[boxno/manifestID],
x.filenumber,
x.DCSID,
x.[DMHS upload Date],
max(p.invtime) [Received Date],
x.FirstName,
x.LastName,
x.MiddleInitial
from x20210324 x
left join PhysicalBatch p
on x.rmn = p.rmn
group by x.RMN,
x.[boxno/manifestID],
x.filenumber,
x.dcsid,
x.[DMHS upload Date],
x.FirstName,
x.LastName,
x.MiddleInitial


select * from x20210324 where [dmhs upload date] is null

