select * from xDCSID20210727
select count(distinct dcsid) from xDCSID20210727

select distinct pp.RMN, c.trackingno, p.Pbatch, 
CONVERT(nvarchar, pp.invtime, 101) CheckInDate , x.dcsid
from xDCSID20210727 x
left join PbatchDCSMapping p
on x.dcsid = p.dcsid
left join PhysicalBatch pp
on p.Pbatch = pp.PBatch
left join customerCheckIn c
on pp.RMN = c.RMN

--into temp
select distinct pp.RMN, c.trackingno, p.Pbatch, 
CONVERT(nvarchar, pp.invtime, 101) CheckInDate , x.dcsid
into xDCSID20210727temp
from xDCSID20210727 x
left join PbatchDCSMapping p
on x.dcsid = p.dcsid
left join PhysicalBatch pp
on p.Pbatch = pp.PBatch
left join customerCheckIn c
on pp.RMN = c.RMN

--8348

select distinct X.RMN, X.TrackingNo, X.BatchName,
X.CheckInDate, X.DCSID, X.Status,
count(distinct d.ImageID) TotalDocs,
count(distinct d.ftpstime) TotalDocsUploaded
FROM
(select distinct T.RMN, T.TrackingNo, T.BatchName,
T.CheckInDate, T.DCSID, s.kbatch,
CASE
	WHEN s.kbatch is not null Then 'Pending Upload'
	ELSE T.Status
	END Status
FROM
(select distinct x.RMN, x.trackingno TrackingNo,
x.Pbatch BatchName, x.CheckInDate, x.dcsid DCSID,
CASE
	WHEN x.CheckInDate is null Then 'Not CheckedIn'
	ELSE 'CheckedIn'
	END Status
from xDCSID20210727temp x) T
left join stats s
on T.BatchName = s.kbatch) X
left join document d
on X.kbatch = d.PBatch and X.DCSID = d.dcsID
group by X.RMN, X.TrackingNo, X.BatchName,
X.CheckInDate, X.DCSID, X.Status


select distinct Y.RMN, Y.TrackingNo, Y.BatchName,
Y.CheckInDate, Y.DCSID, Y.Status,
Y.TotalDocs, Y.TotalDocsUploaded,
count(distinct p.pbatch) cBatches,


select distinct Y.RMN, Y.TrackingNo, Y.BatchName,
Y.CheckInDate, Y.DCSID, Y.Status, Y.TotalDocs, Y.TotalDocsUploaded,
count(distinct p.Pbatch) cBatches,
count(distinct d.pbatch) dBatches
FROM
(select distinct X.RMN, X.TrackingNo, X.BatchName,
X.CheckInDate, X.DCSID, X.Status,
count(distinct d.ImageID) TotalDocs,
count(distinct d.ftpstime) TotalDocsUploaded
FROM
(select distinct T.RMN, T.TrackingNo, T.BatchName,
T.CheckInDate, T.DCSID, s.kbatch,
CASE
	WHEN s.kbatch is not null Then 'Pending Upload'
	ELSE T.Status
	END Status
FROM
(select distinct x.RMN, x.trackingno TrackingNo,
x.Pbatch BatchName, x.CheckInDate, x.dcsid DCSID,
CASE
	WHEN x.CheckInDate is null Then 'Not CheckedIn'
	ELSE 'CheckedIn'
	END Status
from xDCSID20210727temp x) T
left join stats s
on T.BatchName = s.kbatch) X
left join document d
on X.kbatch = d.PBatch and X.DCSID = d.dcsID
group by X.RMN, X.TrackingNo, X.BatchName,
X.CheckInDate, X.DCSID, X.Status) Y
left join pbatchDCSMapping p
on Y.DCSID = p.dcsid
left join document d
on Y.DCSID = d.dcsID
group by Y.RMN, Y.TrackingNo, Y.BatchName,
Y.CheckInDate, Y.DCSID, Y.Status, Y.TotalDocs, Y.TotalDocsUploaded



--into tabulator
select distinct Y.RMN, Y.TrackingNo, Y.BatchName,
Y.CheckInDate, Y.DCSID, Y.Status, Y.TotalDocs, Y.TotalDocsUploaded,
count(distinct p.Pbatch) cBatches,
count(distinct d.pbatch) dBatches
into xDCSID20210727temp2
FROM
(select distinct X.RMN, X.TrackingNo, X.BatchName,
X.CheckInDate, X.DCSID, X.Status,
count(distinct d.ImageID) TotalDocs,
count(distinct d.ftpstime) TotalDocsUploaded
FROM
(select distinct T.RMN, T.TrackingNo, T.BatchName,
T.CheckInDate, T.DCSID, s.kbatch,
CASE
	WHEN s.kbatch is not null Then 'Pending Upload'
	ELSE T.Status
	END Status
FROM
(select distinct x.RMN, x.trackingno TrackingNo,
x.Pbatch BatchName, x.CheckInDate, x.dcsid DCSID,
CASE
	WHEN x.CheckInDate is null Then 'Not CheckedIn'
	ELSE 'CheckedIn'
	END Status
from xDCSID20210727temp x) T
left join stats s
on T.BatchName = s.kbatch) X
left join document d
on X.kbatch = d.PBatch and X.DCSID = d.dcsID
group by X.RMN, X.TrackingNo, X.BatchName,
X.CheckInDate, X.DCSID, X.Status) Y
left join pbatchDCSMapping p
on Y.DCSID = p.dcsid
left join document d
on Y.DCSID = d.dcsID
group by Y.RMN, Y.TrackingNo, Y.BatchName,
Y.CheckInDate, Y.DCSID, Y.Status, Y.TotalDocs, Y.TotalDocsUploaded



select distinct x.RMN, x.TrackingNo,
x.BatchName, x.CheckInDate, x.DCSID,
CASE
	WHEN x.TotalDocs = x.TotalDocsUploaded and 
	x.cBatches = x.dBatches and x.BatchName is not null
	and x.TotalDocs <> 0 Then 'Completed'
	WHEN x.TotalDocs <> x.TotalDocsUploaded and 
	x.cBatches = x.dBatches and x.BatchName is not null
	and x.TotalDocs <> 0 Then 'Pending Upload'
	WHEN x.TotalDocs = x.TotalDocsUploaded and 
	x.cBatches <> x.dBatches and x.BatchName is not null
	and x.TotalDocs <> 0 Then 'WIP'
	ELSE x.Status
	END Status
from xDCSID20210727temp2 x

select * from document where pbatch in (
'02211691007313',
'02211731601701')

select count(distinct pbatch) from PbatchDCSMapping where dcsid = 'KPINELJG-GESSI1'
select count(distinct pbatch) from document where dcsid = 'KPINELJG-GESSI1'

select count(distinct pbatch) from PbatchDCSMapping where dcsid = 'KPINOQAJV28TL0'
select count(distinct pbatch) from document where dcsid = 'KPINOQAJV28TL0'

select * from document where dcsid = 'KPED5Y3Y-RTYRR6'


--into tabulator 3
select distinct x.RMN, x.TrackingNo,
x.BatchName, x.CheckInDate, x.DCSID,
CASE
	WHEN x.TotalDocs = x.TotalDocsUploaded and 
	x.cBatches = x.dBatches and x.BatchName is not null
	and x.TotalDocs <> 0 Then 'Completed'
	WHEN x.TotalDocs <> x.TotalDocsUploaded and 
	x.cBatches = x.dBatches and x.BatchName is not null
	and x.TotalDocs <> 0 Then 'Pending Upload'
	WHEN x.TotalDocs = x.TotalDocsUploaded and 
	x.cBatches <> x.dBatches and x.BatchName is not null
	and x.TotalDocs <> 0 Then 'WIP'
	ELSE x.Status
	END Status
	--into xDCSID20210727temp3
from xDCSID20210727temp2 x
order by x.DCSID






select count(distinct pbatch) from PbatchDCSMapping where dcsid = 'KR3TTYQC-VEV8EO'
select count(distinct pbatch) from document where dcsid = 'KR3TTYQC-VEV8EO'

select count(distinct pbatch) from PbatchDCSMapping where dcsid = 'KR3TTYQC-VEV8EO'
select count(distinct pbatch) from document where dcsid = 'KR3TTYQC-VEV8EO'



select distinct x.RMN, x.TrackingNo,
x.BatchName, x.CheckInDate, x.DCSID,
CASE
	When x.OpenBoxBatchLocation is not null Then x.OpenBoxBatchLocation
	Else x.Status
	END Status
FROM
(select distinct T.RMN, T.TrackingNo,
T.BatchName, T.CheckInDate, T.DCSID,
T.Status,
CASE
	WHEN b.WFStep = 1 Then 'Capture'
	WHEN b.WFStep = 2 Then 'Enhance1'
	WHEN b.WFStep = 3 Then 'FOCR'
	WHEN b.WFStep = 4 Then 'Enhance2'
	WHEN b.WFStep = 5 Then 'Separation'
	WHEN b.WFStep = 6 Then 'ImageQC'
	WHEN b.WFStep = 7 Then 'AutoIndex'
	WHEN b.WFStep = 8 Then 'DocID'
	WHEN b.WFStep = 9 Then 'DocIDQC'
	WHEN b.WFStep = 10 Then 'Manual Index'
	WHEN b.WFStep = 11 Then 'Manual IndexQC'
	WHEN b.WFStep = 12 and batchlocation = 64 then 'Verification'
	WHEN b.WFStep = 13 and batchlocation <> 0 then 'Export'  
	END OpenBoxBatchLocation
FROM
(select distinct x.RMN, x.TrackingNo,
x.BatchName, x.CheckInDate, x.DCSID,
CASE
	WHEN x.TotalDocs = x.TotalDocsUploaded and 
	x.cBatches = x.dBatches and x.BatchName is not null
	and x.TotalDocs <> 0 Then 'Completed'
	WHEN (x.TotalDocs <> x.TotalDocsUploaded) and 
	x.cBatches = x.dBatches and x.BatchName is not null
	and x.TotalDocs <> 0 Then 'Pending Upload'
	--WHEN x.TotalDocs = x.TotalDocsUploaded and 
	--x.cBatches <> x.dBatches and x.BatchName is not null
	--and x.TotalDocs <> 0 Then 'WIP'
	ELSE x.Status
	END Status
from xDCSID20210727temp2 x) T
left join [mtv-va-sql-4\p1].TurboscanNG1.dbo.batches b
on T.BatchName = b.batchname) X
order by x.DCSID

select * from xDCSID20210727temp2 where batchname = '02212031914317'
select * from document where pbatch = '02212031005424'


--good final
select distinct x.RMN, x.TrackingNo,
x.BatchName, x.CheckInDate, x.DCSID,
CASE
	When x.OpenBoxBatchLocation is not null Then x.OpenBoxBatchLocation
	Else x.Status
	END Status
FROM
(select distinct T.RMN, T.TrackingNo,
T.BatchName, T.CheckInDate, T.DCSID,
T.Status,
CASE
	WHEN b.WFStep = 1 Then 'Capture'
	WHEN b.WFStep = 2 Then 'Enhance1'
	WHEN b.WFStep = 3 Then 'FOCR'
	WHEN b.WFStep = 4 Then 'Enhance2'
	WHEN b.WFStep = 5 Then 'Separation'
	WHEN b.WFStep = 6 Then 'ImageQC'
	WHEN b.WFStep = 7 Then 'AutoIndex'
	WHEN b.WFStep = 8 Then 'DocID'
	WHEN b.WFStep = 9 Then 'DocIDQC'
	WHEN b.WFStep = 10 Then 'Manual Index'
	WHEN b.WFStep = 11 Then 'Manual IndexQC'
	WHEN b.WFStep = 12 and batchlocation = 64 then 'Verification'
	WHEN b.WFStep = 13 and batchlocation <> 0 then 'Export'  
	END OpenBoxBatchLocation
FROM
(select distinct x.RMN, x.TrackingNo,
x.BatchName, x.CheckInDate, x.DCSID,
CASE
	WHEN x.TotalDocs = x.TotalDocsUploaded
	and x.BatchName is not null
	and x.TotalDocs <> 0 Then 'Completed'
	WHEN (x.TotalDocs <> x.TotalDocsUploaded) 
	and x.BatchName is not null
	and x.TotalDocs <> 0 Then 'Pending Upload'
	--WHEN x.TotalDocs = x.TotalDocsUploaded and 
	--x.cBatches <> x.dBatches and x.BatchName is not null
	--and x.TotalDocs <> 0 Then 'WIP'
	ELSE x.Status
	END Status
from xDCSID20210727temp2 x) T
left join [mtv-va-sql-4\p1].TurboscanNG1.dbo.batches b
on T.BatchName = b.batchname) X
order by x.DCSID

select distinct x.RMN, x.TrackingNo,
x.BatchName, x.CheckInDate, x.DCSID, x.totalDocs, x.totaldocsuploaded,
CASE
	WHEN x.TotalDocs = x.TotalDocsUploaded and 
	x.cBatches = x.dBatches and x.BatchName is not null
	and x.TotalDocs <> 0 Then 'Completed'
	WHEN x.TotalDocs = x.TotalDocsUploaded 
	and x.BatchName is not null
	and x.TotalDocs <> 0 Then 'Completed'
	WHEN (x.TotalDocs <> x.TotalDocsUploaded) and x.BatchName is not null
	and x.TotalDocs <> 0 Then 'Pending Upload'
	--WHEN x.TotalDocs = x.TotalDocsUploaded and 
	--x.cBatches <> x.dBatches and x.BatchName is not null
	--and x.TotalDocs <> 0 Then 'WIP'
	ELSE x.Status
	END Status
from xDCSID20210727temp2 x
where x.BatchName = '02212031914317'