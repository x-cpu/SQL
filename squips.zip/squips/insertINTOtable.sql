select top(100) * into xtest01 from tempDocument2021

select top(300) * into xtest02 from tempDocument2021

select * from xtest01

select * from xtest02

insert into tempDocument2021p01 (ImageID, PBatch, NumPages, FileNumber, rmn,
docidDoctype, DCSID, FirstName, LastName, tempImageID, [nochange?], 
[pagesDelete?], [split?], [rejectReview?], [Acrobat?], insertDate,
operID, machineName)
select ImageID, PBatch, NumPages, FileNumber, RMN,
docidDoctype, DCSID, FirstName, LastName, tempImageID, [nochange?],
[pagesDelete?], [split?], [rejectReview?], [Acrobat?], insertDate,
operID, machineName from tempDocument2021p02








